#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <tuple>
#include <array>
#include <limits>
#include <queue>
#include <cstdint>

using namespace std;

const long long INF = 1e18; // Use a large number for infinity

struct Job {
    int id;
    int p, d, w;
};

// Sort by EDD
bool compareJobs(const Job& a, const Job& b) {
    if (a.d != b.d) return a.d < b.d;
    return a.id < b.id;
}

// Global data
int n, s;
vector<Job> jobs;
vector<int> p_min_suffix; // p_min^(j)
vector<int> P_suffix;     // P^(j)
vector<long long> P_prefix; // Prefix sum of p on EDD order
vector<int> w_min_prefix;   // Prefix minimum of w on EDD order
vector<int> due_dates_sorted; // EDD-sorted due dates

// Stat Counting
long long total_states = 0;
long long global_upper_bound = INF;
long double current_lb_remain = 0.0L;
int current_prefix_m = 0; // Remaining jobs are {1,...,m} on EDD index

// State Definition
template <size_t N>
struct ArrayHash {
    size_t operator()(const array<int, N>& a) const noexcept {
        size_t h = 1469598103934665603ULL;
        for (size_t i = 0; i < N; ++i) {
            h ^= static_cast<size_t>(a[i] + 0x9e3779b9 + (h << 6) + (h >> 2));
        }
        return h;
    }
};

using Key1 = array<int, 4>; // L1, t1, ud, bd
using Key2 = array<int, 7>; // L1, t1, ud, bd, L2, t2, k
using KeyA2 = array<int, 2>;
using KeyA3 = array<int, 3>;
using KeyA4 = array<int, 4>;
using KeyA6 = array<int, 6>;
using Group43List = vector<tuple<int,int,int,int,int,long long>>;
using Group1List = vector<tuple<int,int,long long>>;

// Mapping state to value
long long f_next_0 = 0;
unordered_map<Key1, long long, ArrayHash<4>> f_next_1;
vector<unordered_map<Key2, long long, ArrayHash<7>>> f_next_b; 

long long f_curr_0 = INF;
unordered_map<Key1, long long, ArrayHash<4>> f_curr_1;
vector<unordered_map<Key2, long long, ArrayHash<7>>> f_curr_b;
vector<int> active_next_b, active_curr_b;
vector<char> in_active_next_b, in_active_curr_b;

inline void mark_active_curr_b(int b) {
    if (!in_active_curr_b[b]) {
        in_active_curr_b[b] = 1;
        active_curr_b.push_back(b);
    }
}

inline __attribute__((always_inline)) void relax_key1(unordered_map<Key1, long long, ArrayHash<4>>& mp, const Key1& key, long long val) {
    if ((long double)val + current_lb_remain > (long double)global_upper_bound) return;
    if (global_upper_bound != INF && val > global_upper_bound) return;
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(std::piecewise_construct, std::forward_as_tuple(key), std::forward_as_tuple(val));
        total_states++;
    }
    else if (val < it->second) it->second = val;
}

inline __attribute__((always_inline)) void relax_key2(int b, const Key2& key, long long val) {
    if ((long double)val + current_lb_remain > (long double)global_upper_bound) return;
    if (global_upper_bound != INF && val > global_upper_bound) return;
    auto& mp = f_curr_b[b];
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(std::piecewise_construct, std::forward_as_tuple(key), std::forward_as_tuple(val));
        mark_active_curr_b(b);
        total_states++;
    } else if (val < it->second) {
        it->second = val;
    }
}

inline __attribute__((always_inline)) bool source_state_survives_stage(long long val) {
    if (global_upper_bound == INF) return true;
    return (long double)val + current_lb_remain <= (long double)global_upper_bound;
}

inline __attribute__((always_inline)) bool source_state_survives_stage_with_add(long long val, long long add_cost) {
    if (global_upper_bound == INF) return true;
    if (add_cost > 0 && val > global_upper_bound - add_cost) return false;
    long long cand = val + add_cost;
    return (long double)cand + current_lb_remain <= (long double)global_upper_bound;
}

// --- State-dependent LB (cheap capacity strengthening on remaining prefix jobs) ---
unordered_map<KeyA2, long long, ArrayHash<2>> state_lb_cache_l1t1;
unordered_map<KeyA4, long long, ArrayHash<4>> state_lb_cache_l1t1l2t2;

inline __attribute__((always_inline)) long long compute_state_extra_lb_l1_t1(int l1, int t1) {
    if (current_prefix_m <= 0) return 0;
    KeyA2 kk = {l1, t1};
    auto it = state_lb_cache_l1t1.find(kk);
    if (it != state_lb_cache_l1t1.end()) return it->second;

    // Remaining jobs are prefix 1..m in EDD order.
    // Consider tau=t1. Jobs with d_i <= tau among the remaining prefix are 1..r.
    int r_all = (int)(upper_bound(due_dates_sorted.begin(), due_dates_sorted.end(), t1) - due_dates_sorted.begin());
    int r = min(current_prefix_m, r_all);
    if (r <= 0) {
        state_lb_cache_l1t1.emplace(kk, 0LL);
        return 0;
    }

    // Before t1, at least one batch B1 of length l1 and one setup s must occupy time.
    // So optimistic capacity for remaining jobs before t1 is at most t1 - s - l1.
    long long cap = max(0LL, (long long)t1 - (long long)s - (long long)l1);
    long long need = P_prefix[r];
    long long excess = max(0LL, need - cap);
    long long lb_extra = excess * (long long)w_min_prefix[r];
    state_lb_cache_l1t1.emplace(kk, lb_extra);
    return lb_extra;
}

inline __attribute__((always_inline)) long double state_lb_for_key1(const Key1& key) {
    auto [l1, t1, ud, bd] = key;
    long long extra = compute_state_extra_lb_l1_t1(l1, t1);
    return max(current_lb_remain, (long double)extra);
}

inline __attribute__((always_inline)) long double state_lb_for_key2(const Key2& key) {
    auto [l1, t1, ud, bd, l2, t2, k] = key;
    long long extra = compute_state_extra_lb_l1_t1(l1, t1);
    if (current_prefix_m > 0) {
        KeyA4 kk = {l1, t1, l2, t2};
        auto it = state_lb_cache_l1t1l2t2.find(kk);
        long long extra2 = 0;
        if (it != state_lb_cache_l1t1l2t2.end()) {
            extra2 = it->second;
        } else {
            int r_all = (int)(upper_bound(due_dates_sorted.begin(), due_dates_sorted.end(), t2) - due_dates_sorted.begin());
            int r = min(current_prefix_m, r_all);
            if (r > 0) {
                // Optimistic usable capacity for remaining-prefix jobs before t2:
                // reserve setup+processing for B1 and B2.
                long long cap2 = max(0LL, (long long)t2 - (long long)(2 * s) - (long long)l1 - (long long)l2);
                long long need2 = P_prefix[r];
                long long excess2 = max(0LL, need2 - cap2);
                extra2 = excess2 * (long long)w_min_prefix[r];
            }
            state_lb_cache_l1t1l2t2.emplace(kk, extra2);
        }
        if (extra2 > extra) extra = extra2;
    }
    return max(current_lb_remain, (long double)extra);
}

inline __attribute__((always_inline)) void relax_key1_lb(unordered_map<Key1, long long, ArrayHash<4>>& mp, const Key1& key, long long val) {
    if (global_upper_bound != INF && val > global_upper_bound) {
        return;
    }
    if ((long double)val + current_lb_remain > (long double)global_upper_bound) {
        return;
    }
    long double lb_state = state_lb_for_key1(key);
    if ((long double)val + lb_state > (long double)global_upper_bound) {
        return;
    }
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(std::piecewise_construct, std::forward_as_tuple(key), std::forward_as_tuple(val));
        total_states++;
    } else if (val < it->second) {
        it->second = val;
    }
}

inline __attribute__((always_inline)) void relax_key2_lb(int b, const Key2& key, long long val) {
    if (global_upper_bound != INF && val > global_upper_bound) {
        return;
    }
    if ((long double)val + current_lb_remain > (long double)global_upper_bound) {
        return;
    }
    long double lb_state = state_lb_for_key2(key);
    if ((long double)val + lb_state > (long double)global_upper_bound) {
        return;
    }
    auto& mp = f_curr_b[b];
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(std::piecewise_construct, std::forward_as_tuple(key), std::forward_as_tuple(val));
        mark_active_curr_b(b);
        total_states++;
    } else if (val < it->second) {
        it->second = val;
    }
}

template <typename K>
inline void relax_min_map(unordered_map<K, long long, ArrayHash<tuple_size<K>::value>>& mp, const K& key, long long val) {
    auto it = mp.find(key);
    if (it == mp.end()) mp.emplace(key, val);
    else if (val < it->second) it->second = val;
}

void clean_maps() {
    f_curr_0 = INF;
    f_curr_1.clear();
    if (f_curr_1.bucket_count() < f_next_1.size()) {
        f_curr_1.reserve(f_next_1.size() * 2 + 16);
    }
    const size_t expected_size = static_cast<size_t>(n + 1);
    if (f_curr_b.size() != expected_size) f_curr_b.resize(expected_size);
    for (int b : active_curr_b) {
        f_curr_b[b].clear();
        in_active_curr_b[b] = 0;
    }
    active_curr_b.clear();
}

void swap_maps() {
    f_next_0 = f_curr_0;
    f_next_1.swap(f_curr_1);
    f_next_b.swap(f_curr_b);
    active_next_b.swap(active_curr_b);
    in_active_next_b.swap(in_active_curr_b);
    const size_t expected_size = static_cast<size_t>(n + 1);
    if (f_next_b.size() != expected_size) f_next_b.resize(expected_size);
    if (f_curr_b.size() != expected_size) f_curr_b.resize(expected_size);
}

long long eval_dpg_on_edd_upper_bound() {
    // Objective-only port of Algorithm_DP_G/src/cpp/dp_g_core.cpp.
    // Runs DP-G on the current EDD-ordered jobs and returns a feasible-schedule UB for DP-F.
    if (n <= 0) return 0;

    using CostType = int32_t;
    const CostType INF_VAL = 1000000000;

    vector<int> p(n + 2, 0), d(n + 2, 0), w(n + 2, 0);
    for (int i = 0; i < n; ++i) {
        p[i + 1] = jobs[i].p;
        d[i + 1] = jobs[i].d;
        w[i + 1] = jobs[i].w;
    }

    vector<int> P_sum(n + 2, 0);
    for (int j = n; j >= 1; --j) P_sum[j] = p[j] + P_sum[j + 1];

    vector<int> p_min(n + 2, 1000000000);
    for (int j = n; j >= 1; --j) p_min[j] = min(p[j], p_min[j + 1]);

    const int max_P = P_sum[1];
    const int full_T = (n + 1) * s + max_P + 10;
    int max_dom = 0;
    for (int j = 1; j <= n; ++j) max_dom = max(max_dom, d[j] + p[j] - 1);
    if (max_dom < s) max_dom = s;
    const int max_T = min(full_T, max_dom);

    vector<CostType> reject_sum(n + 2, 0);
    long long acc = 0;
    for (int j = n; j >= 1; --j) {
        acc += 1LL * w[j] * p[j];
        if (acc > INF_VAL) acc = INF_VAL;
        reject_sum[j] = (CostType)acc;
    }
    reject_sum[n + 1] = 0;

    auto at = [max_T](int L, int t) -> size_t {
        return (size_t)L * (size_t)(max_T + 1) + (size_t)t;
    };

    vector<CostType> curr((size_t)(max_P + 1) * (size_t)(max_T + 1), INF_VAL);
    vector<CostType> next((size_t)(max_P + 1) * (size_t)(max_T + 1), INF_VAL);

    for (int t = s; t <= max_T; ++t) next[at(0, t)] = 0;

    for (int j = n; j >= 1; --j) {
        fill(curr.begin(), curr.end(), INF_VAL);

        const int pj = p[j], dj = d[j], wj = w[j];
        const int t_cutoff = min(max_T, dj + pj - 1);
        const int loop_end_valid = t_cutoff;

        vector<CostType> H;
        if (loop_end_valid >= 0) {
            const CostType reject_next = reject_sum[j + 1];
            H.assign(loop_end_valid + 1, reject_next);
            for (int t = 0; t <= loop_end_valid; ++t) {
                int limLp = min(P_sum[j + 1], max_T - s - t);
                if (limLp < 0) continue;
                CostType best = H[t];
                for (int Lp = 0; Lp <= limLp; ++Lp) {
                    CostType v = next[at(Lp, t + s + Lp)];
                    if (v < best) best = v;
                }
                H[t] = best;
            }
        }

        vector<CostType> late_cost;
        if (loop_end_valid >= 0) {
            late_cost.resize(loop_end_valid + 1);
            for (int t = 0; t <= loop_end_valid; ++t) {
                long long lw = 1LL * wj * max(0, t - dj);
                if (lw > INF_VAL) lw = INF_VAL;
                late_cost[t] = (CostType)lw;
            }
        }

        const int pm_next = (j < n) ? p_min[j + 1] : 1000000000;

        for (int L = 0; L <= P_sum[j]; ++L) {
            size_t row_idx = (size_t)L * (size_t)(max_T + 1);
            int start_t = s + L;

            bool L_forces_late =
                (p[j] > 0 && (p_min[j] < L && L < pj)) ||
                (pm_next < 1000000000 && (pj < L && L < pj + pm_next));

            if (start_t <= loop_end_valid) {
                for (int t = start_t; t <= loop_end_valid; ++t) {
                    CostType res = INF_VAL;

                    if (L <= P_sum[j + 1]) {
                        CostType v_late = next[row_idx + (size_t)t];
                        if (v_late < INF_VAL) {
                            long long cand = (long long)v_late + 1LL * wj * pj;
                            if (cand > INF_VAL) cand = INF_VAL;
                            res = (CostType)cand;
                        }
                    }

                    if (!L_forces_late) {
                        CostType lw = late_cost[t];
                        if (L >= pj + pm_next) {
                            int Lp = L - pj;
                            CostType v_join = next[(size_t)Lp * (size_t)(max_T + 1) + (size_t)t];
                            if (v_join < INF_VAL) {
                                CostType cand = (CostType)min<long long>((long long)INF_VAL, (long long)v_join + (long long)lw);
                                if (cand < res) res = cand;
                            }
                        }
                        if (L == pj) {
                            CostType v_unique = H[t];
                            if (v_unique < INF_VAL) {
                                CostType cand = (CostType)min<long long>((long long)INF_VAL, (long long)v_unique + (long long)lw);
                                if (cand < res) res = cand;
                            }
                        }
                    }

                    curr[row_idx + (size_t)t] = res;
                }
            }

            int start_t_late = max(start_t, loop_end_valid + 1);
            if (start_t_late <= max_T && L <= P_sum[j + 1]) {
                for (int t = start_t_late; t <= max_T; ++t) {
                    CostType v_late = next[row_idx + (size_t)t];
                    if (v_late < INF_VAL) {
                        long long cand = (long long)v_late + 1LL * wj * pj;
                        if (cand > INF_VAL) cand = INF_VAL;
                        curr[row_idx + (size_t)t] = (CostType)cand;
                    }
                }
            }
        }

        next.swap(curr);
    }

    long long ans = INF;
    for (int L = 0; L <= max_P; ++L) {
        int t = s + L;
        if (t <= max_T) {
            CostType v = next[at(L, t)];
            if ((long long)v < ans) ans = (long long)v;
        }
    }
    return (ans >= INF_VAL ? INF : ans);
}

inline long long cap_time_upper_by_ub(long long base_cost, int w, int d, long long t_upper) {
    if (t_upper < numeric_limits<long long>::min() / 4) return t_upper;
    if (global_upper_bound == INF) return t_upper;
    if (base_cost > global_upper_bound) return numeric_limits<long long>::min();
    if (w <= 0) return t_upper;
    long long slack = (global_upper_bound - base_cost) / (long long)w;
    long long ub_t = (long long)d + slack;
    return min(t_upper, ub_t);
}

vector<long double> compute_prefix_preemptive_lb() {
    // lb[m]: preemptive-relaxation lower bound for first m jobs (EDD prefix), with one setup s.
    vector<long double> lb(n + 1, 0.0L);
    // min-heap by weight over selected early-work chunks: (w, amount).
    priority_queue<pair<int, long long>, vector<pair<int, long long>>, greater<pair<int, long long>>> pq;
    long long selected = 0;
    long double early_profit = 0.0L;
    long double total_wp = 0.0L;

    for (int i = 1; i <= n; ++i) {
        const auto& J = jobs[i - 1];
        selected += J.p;
        early_profit += (long double)J.w * (long double)J.p;
        total_wp += (long double)J.w * (long double)J.p;
        pq.push({J.w, J.p});

        long long cap = max(0, J.d - s);
        while (selected > cap && !pq.empty()) {
            auto [w, amt] = pq.top();
            pq.pop();
            long long drop = min(amt, selected - cap);
            selected -= drop;
            early_profit -= (long double)w * (long double)drop;
            amt -= drop;
            if (amt > 0) pq.push({w, amt});
        }

        long double cur_lb = total_wp - early_profit;
        if (cur_lb < 0.0L) cur_lb = 0.0L;
        lb[i] = cur_lb;
    }
    return lb;
}

bool can_achieve_zero_late_work() {
    // Exact Y_w^*=0 feasibility check via 1|s-batch|L_max <= 0 characterization:
    // jobs are in EDD order and each batch is a contiguous block.
    vector<long long> pref(n + 1, 0LL);
    for (int i = 1; i <= n; ++i) pref[i] = pref[i - 1] + (long long)jobs[i - 1].p;

    vector<vector<char>> feasible(n + 1, vector<char>(n + 1, 0));
    feasible[0][0] = 1;

    for (int k = 1; k <= n; ++k) {
        for (int i = k; i <= n; ++i) {
            long long C = (long long)k * (long long)s + pref[i];
            for (int t = k - 1; t <= i - 1; ++t) {
                if (!feasible[t][k - 1]) continue;
                // Last batch is jobs t+1..i. In EDD order its tightest due date is d_{t+1}.
                if (C <= (long long)jobs[t].d) {
                    feasible[i][k] = 1;
                    break;
                }
            }
        }
    }

    for (int k = 1; k <= n; ++k) {
        if (feasible[n][k]) return true;
    }
    return false;
}

int main() {
    /* if (freopen("input.txt", "r", stdin) == NULL) {
    } */
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    if (!(cin >> n >> s)) return 0;
    jobs.resize(n);
    for (int i = 0; i < n; ++i) {
        jobs[i].id = i + 1;
        cin >> jobs[i].p >> jobs[i].d >> jobs[i].w;
    }

    sort(jobs.begin(), jobs.end(), compareJobs);
    due_dates_sorted.assign(n, 0);
    for (int i = 0; i < n; ++i) due_dates_sorted[i] = jobs[i].d;

    // Exact early termination: if Y_w^* = 0 is feasible, return immediately.
    if (can_achieve_zero_late_work()) {
        cout << 0 << " " << 1 << "\n";
        return 0;
    }

    // Prefix helpers on EDD order for state-dependent lower bounds.
    P_prefix.assign(n + 1, 0);
    w_min_prefix.assign(n + 1, 1000000000);
    for (int i = 1; i <= n; ++i) {
        P_prefix[i] = P_prefix[i - 1] + jobs[i - 1].p;
        w_min_prefix[i] = min(w_min_prefix[i - 1], jobs[i - 1].w);
    }
    
    // Calculate total P for horizon
    long long total_P = 0;
    for(const auto& job : jobs) total_P += job.p;
    long long horizon = (long long)n * s + total_P;
    global_upper_bound = eval_dpg_on_edd_upper_bound();
    vector<long double> lb_prefix(n + 1, 0.0L);
    {
        auto lb_pre = compute_prefix_preemptive_lb();
        for (int i = 0; i <= n; ++i) lb_prefix[i] = max(lb_prefix[i], lb_pre[i]);
    }

    f_curr_b.resize(n + 1);
    in_active_next_b.assign(n + 1, 0);
    in_active_curr_b.assign(n + 1, 0);

    // Precompute Min P Suffix and Sum P Suffix
    p_min_suffix.assign(n + 2, 0);
    P_suffix.assign(n + 2, 0);
    int current_min_p = 2000000000;
    int current_sum_p = 0;
    for (int j = n; j >= 1; --j) {
        current_min_p = min(current_min_p, jobs[j-1].p);
        current_sum_p += jobs[j-1].p;
        p_min_suffix[j] = current_min_p;
        P_suffix[j] = current_sum_p;
    }

    // Initialization
    f_next_0 = 0;
    f_next_1[{0, 0, 0, 0}] = 0;
    f_next_b.resize(n + 1);
    vector<unordered_map<KeyA6, long long, ArrayHash<6>>> tilde_fb_x2(n + 1);
    vector<unordered_map<KeyA2, Group43List, ArrayHash<2>>> grouped_by_L1T1(n + 1);
    vector<unordered_map<KeyA4, vector<pair<int,long long>>, ArrayHash<4>>> precalc_46(n + 1);
    unordered_map<KeyA3, long long, ArrayHash<3>> tilde_f1_22;
    unordered_map<KeyA2, Group1List, ArrayHash<2>> grouped_1_by_L1T1;
    vector<int> b_to_process;
    vector<int> b_mark_touched;
    vector<char> b_mark(n + 1, 0);
    vector<char> need_tilde(n + 1, 0);
    vector<char> need_group(n + 1, 0);
    vector<long long> min_next_b_val(n + 1, INF);

    // Main Loop j = n to 1
    for (int j = n; j >= 1; --j) {
        Job J = jobs[j-1]; // Current job
        int jobs_processed = n - j + 1;
        current_prefix_m = j - 1;
        state_lb_cache_l1t1.clear();
        if (state_lb_cache_l1t1.bucket_count() < f_next_1.size() + 64) {
            state_lb_cache_l1t1.reserve(f_next_1.size() + 64);
        }
        state_lb_cache_l1t1l2t2.clear();
        size_t want = min<size_t>(f_next_1.size() * 4 + 64, 1u << 20);
        if (state_lb_cache_l1t1l2t2.bucket_count() < want) {
            state_lb_cache_l1t1l2t2.reserve(want);
        }
        current_lb_remain = lb_prefix[j - 1];
        clean_maps();

        // 1. Pre-calculation for Subcase 2.2:
        // \tilde{f}_{j+1}^1(L1, t1, bd) = min_{ud' <= bd} f_{j+1}^1(L1, t1, ud', bd)
        long long min_next1_val = INF;
        tilde_f1_22.clear();
        tilde_f1_22.reserve(f_next_1.size() + 16);
        for (auto const& [key, val] : f_next_1) {
            if (!source_state_survives_stage(val)) continue;
            if (val < min_next1_val) min_next1_val = val;
            auto [l1, t1, ud, bd] = key;
            KeyA3 aux_key = {l1, t1, bd};
            relax_min_map(tilde_f1_22, aux_key, val);
        }

        // CASE b >= 2: indices that will actually be processed this layer.
        b_to_process.clear();
        b_mark_touched.clear();
        auto add_b = [&](int x) {
            if (x < 2 || x > n) return;
            if (!b_mark[x]) {
                b_mark[x] = 1;
                b_to_process.push_back(x);
                b_mark_touched.push_back(x);
            }
        };
        if (min_next1_val != INF && jobs_processed >= 2) add_b(2);
        for (int b : active_next_b) {
            if (b <= jobs_processed) add_b(b);
            if (b + 1 <= jobs_processed) add_b(b + 1);
        }

        for (int b : b_mark_touched) {
            need_tilde[b] = 1;
            if (b >= 3) need_group[b - 1] = 1;
        }

        // 2. Pre-calculation for Subcase 3.2, 4.2:
        // \tilde{f}_{j+1}^b(L1, t1, bd, L2, t2, k) = min_{ud' <= bd} f_{j+1}^b(...)
        for (int b : b_mark_touched) {
            tilde_fb_x2[b].clear();
            min_next_b_val[b] = INF;
        }
        for (int b = 2; b <= jobs_processed; ++b) {
            if (need_group[b]) {
                grouped_by_L1T1[b].clear();
                precalc_46[b].clear();
            }
        }
        for (int b : active_next_b) {
            if (b > jobs_processed) continue;
            bool want_tilde = need_tilde[b];
            bool want_group = need_group[b];
            if (!want_tilde && !want_group) continue;

            const auto& src_map = f_next_b[b];
            if (want_tilde) {
                tilde_fb_x2[b].reserve(src_map.size() + 16);
            }
            if (want_group) {
                grouped_by_L1T1[b].reserve(src_map.size() + 16);
                precalc_46[b].reserve(src_map.size() / 2 + 16);
            }

            long long min_val = INF;
            for (auto const& [key, val] : src_map) {
                if (!source_state_survives_stage(val)) continue;
                if (val < min_val) min_val = val;
                auto [l1, t1, ud, bd, l2, t2, k] = key;
                if (want_tilde) {
                    KeyA6 aux_key = {l1, t1, bd, l2, t2, k};
                    relax_min_map(tilde_fb_x2[b], aux_key, val);
                }
                if (want_group) {
                    grouped_by_L1T1[b][KeyA2{l1, t1}].emplace_back(ud, bd, l2, t2, k, val);
                    if (k == 0) {
                        // Subcase 4.6 feasibility on inserted B2 completion:
                        // t2_new + s <= start(B3 processing) = t2' - L2'
                        // => t2_new <= t2' - L2' - s
                        long long mx_ll = (long long)t2 - l2 - 1LL * s;
                        if (mx_ll >= numeric_limits<int>::min() && mx_ll <= numeric_limits<int>::max()) {
                            precalc_46[b][KeyA4{l1, t1, ud, bd}].emplace_back((int)mx_ll, val);
                        }
                    }
                }
            }
            min_next_b_val[b] = min_val;

            if (want_group) {
                for (auto& [_, vec] : precalc_46[b]) {
                    sort(vec.begin(), vec.end(), [](const auto& a, const auto& b2) {
                        if (a.first != b2.first) return a.first > b2.first;
                        return a.second < b2.second;
                    });
                }
            }
        }
        
        bool need_group1_for_b2 = b_mark[2] && (min_next1_val != INF);
        if (need_group1_for_b2) {
            grouped_1_by_L1T1.clear();
            grouped_1_by_L1T1.reserve(f_next_1.size() + 16);
            for (auto const& [key, val] : f_next_1) {
                if (!source_state_survives_stage(val)) continue;
                auto [l1, t1, ud, bd] = key;
                grouped_1_by_L1T1[KeyA2{l1, t1}].emplace_back(ud, bd, val);
            }
        } else {
            grouped_1_by_L1T1.clear();
        }

        // --- DP TRANSITION ---

        // CASE 1: b=0
        long long late_full_cost = (long long)J.w * J.p;
        if (f_next_0 != INF && source_state_survives_stage_with_add(f_next_0, late_full_cost)) {
             long long cand = f_next_0 + late_full_cost;
             if ((long double)cand + current_lb_remain <= (long double)global_upper_bound &&
                 (global_upper_bound == INF || cand <= global_upper_bound)) {
                 f_curr_0 = cand;
             }
        }

        // CASE 2: b=1
        // Subcase 2.1: Late
        bool run_subcase_21 = (min_next1_val != INF) && source_state_survives_stage_with_add(min_next1_val, late_full_cost);
        if (run_subcase_21) {
            for (auto const& [key, val] : f_next_1) {
                if (!source_state_survives_stage_with_add(val, late_full_cost)) continue;
                long long cost = val + late_full_cost;
                relax_key1_lb(f_curr_1, key, cost);
            }
        }

        // Subcase 2.2: J_j in B_1 (with others)
        for (auto const& [aux_key, val] : tilde_f1_22) {
            auto [l1_prev, t1, bd] = aux_key;
            if (l1_prev < p_min_suffix[j+1]) continue;
            if (t1 >= J.d + J.p) continue;
            
            Key1 new_key = {l1_prev + J.p, t1, J.d, bd};
            long long add_cost = (long long)J.w * max(0, t1 - J.d);
            long long total_cost = val + add_cost;
            relax_key1_lb(f_curr_1, new_key, total_cost);
        }

        // Subcase 2.3: J_j is ONLY job in B_1
        if (f_next_0 != INF && source_state_survives_stage(f_next_0)) {
            long long max_t1 = horizon;
            long long limit_t1 = min(max_t1, (long long)J.d + J.p - 1LL);

            long long min_t = s + J.p;
            long long capped_hi = cap_time_upper_by_ub(f_next_0, J.w, J.d, limit_t1);
            long long base_cost = f_next_0;
            long long w_val = J.w;
            int d_val = J.d;
            int p_val = J.p;
            Key1 new_key_base = {p_val, 0, d_val, d_val};

            long long tard = max(0LL, min_t - (long long)d_val);
            for (long long t = min_t; t <= capped_hi; ++t) {
                new_key_base[1] = (int)t;
                long long cost = base_cost + (long long)w_val * tard;
                relax_key1_lb(f_curr_1, new_key_base, cost);
                if (t >= (long long)d_val) ++tard;
            }
        }


        for (int b : b_to_process) {
            auto& target_b = f_curr_b[b];
            size_t expected = f_next_b[b].size() + tilde_fb_x2[b].size();
            if (b == 2) expected += f_next_1.size();
            if (b - 1 >= 2) expected += grouped_by_L1T1[b - 1].size();
            if (target_b.bucket_count() < expected + 16) {
                target_b.reserve(expected * 2 + 16);
            }

            // Subcase X.2: J_j in B_1 (with others)
            for (auto const& [aux_key, val] : tilde_fb_x2[b]) {
                auto [l1_prev, t1, bd, l2, t2, k] = aux_key;
                if (l1_prev < p_min_suffix[j+1]) continue;
                if (t1 >= J.d + J.p) continue;
                
                Key2 new_key = {l1_prev + J.p, t1, J.d, bd, l2, t2, k};
                long long cost = val + (long long)J.w * max(0, t1 - J.d);
                relax_key2_lb(b, new_key, cost);
            }

            // Subcase X.1 (Late) and Subcase 3.5/3.6, 4.4/4.5 share the same source map.
            // Iterate once and apply both transitions.
            bool run_subcase_x1 = (min_next_b_val[b] != INF) &&
                                  source_state_survives_stage_with_add(min_next_b_val[b], late_full_cost);
            bool run_subcase_x35 = (min_next_b_val[b] != INF);
            if (run_subcase_x1 || run_subcase_x35) {
                for (auto const& [key, val] : f_next_b[b]) {
                    if (!source_state_survives_stage(val)) continue;
                    auto [l1, t1, ud, bd, l2_prev, t2, k_prev] = key;

                    if (run_subcase_x1 && source_state_survives_stage_with_add(val, late_full_cost)) {
                        long long cost_late = val + late_full_cost;
                        relax_key2_lb(b, key, cost_late);
                    }

                    if (!run_subcase_x35) continue;
                    // J_j is non-late in B2 and B2 already contains at least one job from J^(j+1).
                    // Recurrence source keeps (L1,t1,ud,bd,t2) and uses L2' = L2 - p_j with k' range:
                    // - if bd > d_j then new k=2 and k' in {0,1,2}
                    // - if bd = d_j then new k=1 and k' in {0,1}

                    // Need at least one other job already in B2.
                    if (l2_prev < p_min_suffix[j + 1]) continue;
                    // J_j must be non-late in B2.
                    if (t2 >= J.d + J.p) continue;

                    int k_new = -1;
                    if (bd > J.d) {
                        // Disturbed in B2: k' can be 0/1/2.
                        k_new = 2;
                    } else if (bd == J.d) {
                        // Semi-disturbed in B2: k' can be 0/1.
                        if (k_prev > 1) continue;
                        k_new = 1;
                    } else {
                        // EDD order should make this practically impossible here.
                        continue;
                    }

                    int l2_new = l2_prev + J.p;
                    // State feasibility: B2 completion cannot be earlier than its own processing window after B1.
                    if ((long long)t2 < (long long)t1 + s + l2_new) continue;

                    Key2 new_key = {l1, t1, ud, bd, l2_new, t2, k_new};
                    long long cost = val + (long long)J.w * max(0, t2 - J.d);
                    relax_key2_lb(b, new_key, cost);
                }
            }
            
            // Subcase X.3 / 4.3 (New B_1 = J_j, Old B_1 -> B_2) [Small before Large]
            
            if (b == 2) {
                 for (auto const& [next_pair, list] : grouped_1_by_L1T1) {
                    int l2_new = next_pair[0];
                    int t2_new = next_pair[1];
                    
                    long long max_t1 = (long long)t2_new - s - l2_new;
                    long long min_t1 = s + J.p;
                    if (max_t1 < min_t1) continue;
                    
                    long long limit = min(max_t1, (long long)J.d + J.p - 1LL);
                    // Pre-calculate minima by induced k_new (equivalent to minimizing over ud',bd').
                    long long best_k[3] = {INF, INF, INF};
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, val] = entry;
                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1; 
                        else k_new = 2;
                        best_k[k_new] = min(best_k[k_new], val);
                    }

                    for (int k_new = 0; k_new <= 2; ++k_new) {
                        if (best_k[k_new] == INF) continue;
                        long long capped_hi = cap_time_upper_by_ub(best_k[k_new], J.w, J.d, limit);
                        long long tard = max(0LL, min_t1 - (long long)J.d);
                        for (long long t = min_t1; t <= capped_hi; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = best_k[k_new] + (long long)J.w * tard;
                            relax_key2_lb(b, new_key, cost);
                            if (t >= (long long)J.d) ++tard;
                        }
                    }
                 }
                 
                 // Subcase 3.7: J_j in B_2 (Result b=2). Source f_next_1 (b=1).
                 // B1 is preserved from suffix. B2 is J_j.
                 for (auto const& [key, val] : f_next_1) {
                    if (!source_state_survives_stage(val)) continue;
                    auto [l1_prev, t1, ud, bd] = key;
                    // k_new encodes d_j relative to B1 due-date range [ud, bd].
                    // Under EDD this is typically 1 or 2; keep full mapping for safety.
                    int k_new = 0;
                    if (J.d > bd) k_new = 0;
                    else if (J.d == bd) k_new = 1;
                    else k_new = 2;

                    long long min_t2 = (long long)t1 + s + J.p;
                    long long max_t2 = min(horizon, (long long)J.d + J.p - 1LL);
                    max_t2 = cap_time_upper_by_ub(val, J.w, J.d, max_t2);
                    
                    if (min_t2 > max_t2) continue;
                    
                    long long tard = max(0LL, min_t2 - (long long)J.d);
                    for(long long t2 = min_t2; t2 <= max_t2; ++t2) {
                        Key2 new_key = {l1_prev, t1, ud, bd, J.p, (int)t2, k_new};
                        long long cost = val + (long long)J.w * tard;
                        relax_key2_lb(b, new_key, cost);
                        if (t2 >= (long long)J.d) ++tard;
                    }
                 }

            } else {
                 // b >= 3
                 // Subcase 4.3 (Small before Large)
                 for (auto const& [next_pair, list] : grouped_by_L1T1[b-1]) {
                    int l2_new = next_pair[0];
                    int t2_new = next_pair[1];
                     
                    long long max_t1 = (long long)t2_new - s - l2_new;
                    long long min_t1 = s + J.p;
                    if (max_t1 < min_t1) continue;
                    
                    long long limit = min(max_t1, (long long)J.d + J.p - 1LL);
                    // Pre-calculate minima by induced k_new with original feasibility filter.
                    long long best_k[3] = {INF, INF, INF};
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, l3, t3, k_next, val] = entry;

                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1;
                        else k_new = 2;

                        if (k_new == 2 && k_next != 0) continue;
                        best_k[k_new] = min(best_k[k_new], val);
                    }

                    for (int k_new = 0; k_new <= 2; ++k_new) {
                        if (best_k[k_new] == INF) continue;
                        long long capped_hi = cap_time_upper_by_ub(best_k[k_new], J.w, J.d, limit);
                        long long tard = max(0LL, min_t1 - (long long)J.d);
                        for (long long t = min_t1; t <= capped_hi; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = best_k[k_new] + (long long)J.w * tard;
                            relax_key2_lb(b, new_key, cost);
                            if (t >= (long long)J.d) ++tard;
                        }
                    }
                 }
                 
                 // Subcase 4.6 (Large before Small)
                 // J_j inserted in B2. B1 preserved.
                 // Source: f_next_{b-1}. (b-1 must be >= 2 for B1, B2 to exist... Wait.)
                 // If suffix has b-1 batches. B1 is suffix B1.
                 // B2 is J_j.
                 // B3 is suffix B2.
                 // We need to fit J_j between B1 and B3.
                 // Query f_next_{b-1} grouped by (L1, t1).
                 // For each (L1, t1) group, we have list of (ud, bd, L2_suffix, t2_suffix, k_suffix).
                 // Here L2_suffix is start of B3 (relative to B1).
                 // Wait. Suffix B2 is our B3.
                 // Start of Suffix B2 processing: t2_suffix - L2_suffix.
                 // We need one setup between inserted B2 and suffix B2.
                 // So t2_new + s <= t2_suffix - L2_suffix.
                 // t2_new <= t2_suffix - L2_suffix - s.
                 // Also t2_new >= t1 + s + p_j.
                 
                 for (auto const& [k46, list] : precalc_46[b-1]) {
                    auto [l1_prev, t1_prev, ud, bd] = k46;
                    // B1 preserved.
                    // k for current state in Subcase 4.6 must be 1 (semi) or 2 (disturbed).
                    int k_new = -1;
                    if (J.d == bd) k_new = 1;
                    else if (J.d < bd) k_new = 2;
                    else continue; // J_j cannot be non-disturbed in Subcase 4.6.

                    long long min_t2_ll = (long long)t1_prev + s + J.p;
                    long long max_t2_ll = min((long long)J.d + J.p - 1LL, horizon);
                    if (min_t2_ll > max_t2_ll) continue;

                    int min_t2 = (int)min_t2_ll;
                    int max_t2 = (int)max_t2_ll;
                    long long list_min_val = INF;
                    for (const auto& pr : list) list_min_val = min(list_min_val, pr.second);
                    long long capped_hi = cap_time_upper_by_ub(list_min_val, J.w, J.d, max_t2);
                    if (capped_hi < min_t2) continue;
                    max_t2 = (int)capped_hi;

                    long long best_val = INF;
                    size_t ptr = 0;
                    long long tard = max(0LL, (long long)max_t2 - (long long)J.d);
                    for (int t2 = max_t2; t2 >= min_t2; --t2) {
                        while (ptr < list.size() && list[ptr].first >= t2) {
                            best_val = min(best_val, list[ptr].second);
                            ++ptr;
                        }
                        if (best_val == INF) continue;
                        Key2 new_key = {l1_prev, t1_prev, ud, bd, J.p, t2, k_new};
                        long long cost = best_val + (long long)J.w * tard;
                        relax_key2_lb(b, new_key, cost);
                        if (t2 > J.d) --tard;
                    }
                 }
            }

        } // end b loop
        for (int x : b_mark_touched) {
            b_mark[x] = 0;
            need_tilde[x] = 0;
            if (x >= 3) need_group[x - 1] = 0;
        }

        swap_maps();
    } // end j loop

    // Final result
    long long ans = INF;
    if (f_next_0 != INF) ans = min(ans, f_next_0);
    
    for (auto const& [key, val] : f_next_1) {
        auto [l1, t1, ud, bd] = key;
        if (t1 == s + l1) {
             ans = min(ans, val);
        }
    }
    
    // Check f_next_b
    if (n >= 2 && in_active_next_b[2]) {
        for (auto const& [key, val] : f_next_b[2]) {
             auto [l1, t1, ud, bd, l2, t2, k] = key;
             if (t1 == s + l1 && t2 == t1 + s + l2) {
                 ans = min(ans, val);
             }
        }
    }

    for (int b : active_next_b) {
        if (b < 3) continue;
        for (auto const& [key, val] : f_next_b[b]) {
             auto [l1, t1, ud, bd, l2, t2, k] = key;
             if (t1 == s + l1 && t2 == t1 + s + l2) {
                 ans = min(ans, val);
             }
        }
    }
    ans = min(ans, global_upper_bound);

    cout << ans << " " << total_states << endl;

    return 0;
}
