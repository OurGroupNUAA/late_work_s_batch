
import sys
try:
    import gurobipy as gp
    from gurobipy import GRB
except ImportError:
    gp = None
    GRB = None

def solve_gurobi_generic(n, s, jobs, time_limit=None):
    if gp is None:
        return float('inf'), 'GUROBI_NOT_INSTALLED'
    try:
        gp.setParam('OutputFlag', 0)
        # Create a new model
        m = gp.Model("BatchSchedulingGeneric")
        
        # Parameters
        if time_limit is not None and time_limit > 0:
            m.Params.TimeLimit = float(time_limit)
        else:
            # Override any external/default config and force no time limit.
            m.Params.TimeLimit = GRB.INFINITY
        m.Params.OutputFlag = 0
        m.Params.Threads = 1
        
        # Max number of batches is n (one job per batch)
        K = n
        batches = range(K)
        
        # Variables
        # x[j, k] = 1 if job j is assigned to batch k
        x = m.addVars(n, K, vtype=GRB.BINARY, name="x")
        
        # u[k] = 1 if batch k is non-empty
        u = m.addVars(K, vtype=GRB.BINARY, name="u")
        
        # C[k] = Completion time of batch k
        C = m.addVars(K, vtype=GRB.CONTINUOUS, name="C")
        
        # z[j] = 1 if job j is fully late (saturated at p_j)
        z = m.addVars(n, vtype=GRB.BINARY, name="z")
        
        # Y[j] = Partial late work 
        Y = m.addVars(n, vtype=GRB.CONTINUOUS, lb=0.0, name="Y")
        
        # Constraints
        
        # 1. Assignment: Each job assigned to exactly one batch
        for j in range(n):
            m.addConstr(sum(x[j, k] for k in batches) == 1, name=f"Assign_j{j}")
            
        # 2. Batch Usage: u[k] >= x[j,k]
        for k in batches:
            for j in range(n):
                m.addConstr(u[k] >= x[j, k], name=f"Usage_k{k}_j{j}")
        
        # 3. Symmetry Breaking
        for k in range(K-1):
            m.addConstr(u[k] >= u[k+1], name=f"Order_u{k}")
            
        # 4. Completion Time
        # k=0
        processing_0 = sum(jobs[j].p * x[j, 0] for j in range(n))
        m.addConstr(C[0] == s * u[0] + processing_0, name="C_0")
        
        for k in range(1, K):
            processing_k = sum(jobs[j].p * x[j, k] for j in range(n))
            m.addConstr(C[k] == C[k-1] + s * u[k] + processing_k, name=f"C_{k}")
            
        # 5. Late Work Definition
        BigM = sum(job.p for job in jobs) + n * s + 10000
        
        for j in range(n):
            for k in batches:
                # If z=0 and x=1: Y >= C - d
                m.addConstr(Y[j] >= C[k] - jobs[j].d - BigM * (1 - x[j, k]) - BigM * z[j], name=f"Late_j{j}_k{k}")
                 
        # Objective
        obj = sum(jobs[j].w * Y[j] + jobs[j].w * jobs[j].p * z[j] for j in range(n))
        m.setObjective(obj, GRB.MINIMIZE)
        
        # Optimize
        m.optimize()
        
        if m.status in [GRB.OPTIMAL, GRB.TIME_LIMIT]:
            return m.objVal, "OPTIMAL" if m.status==GRB.OPTIMAL else "TIMEOUT"
        else:
            return float('inf'), f"ERR_{m.status}"
            
    except Exception as e:
        return float('inf'), f"EXC_{e}"
