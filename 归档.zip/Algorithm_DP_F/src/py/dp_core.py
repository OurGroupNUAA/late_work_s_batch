import subprocess
from pathlib import Path


def _run_binary(binary_path, instance, time_limit=None):
    payload = [f"{instance.n} {instance.s}"] + [f"{j.p} {j.d} {j.w}" for j in instance.jobs]
    input_str = "\n".join(payload) + "\n"
    try:
        proc = subprocess.run(
            [str(binary_path)],
            input=input_str,
            text=True,
            capture_output=True,
            timeout=time_limit,
            check=True,
        )
        out = proc.stdout.strip().split()
        if len(out) >= 2:
            return float(out[0]), int(out[1]), "OPTIMAL"
        return float("inf"), 0, "BAD_OUTPUT"
    except subprocess.TimeoutExpired:
        return float("inf"), 0, "TIMEOUT"
    except (subprocess.CalledProcessError, ValueError):
        return float("inf"), 0, "ERROR"


class DPSolverFBase:
    def __init__(self, instance):
        self.instance = instance
        root = Path(__file__).resolve().parents[2]
        self.binary_path = root / "bin" / "algorithm_dp_f"
        if not self.binary_path.exists():
            raise FileNotFoundError(f"Binary not found at {self.binary_path}. Run scripts/build_cpp.sh first.")

    def solve(self, time_limit=None):
        return _run_binary(self.binary_path, self.instance, time_limit=time_limit)


class DPSolverFSpeedup:
    def __init__(self, instance):
        self.instance = instance
        root = Path(__file__).resolve().parents[2]
        self.binary_path = root / "bin" / "algorithm_dp_f_speedup"
        if not self.binary_path.exists():
            raise FileNotFoundError(f"Binary not found at {self.binary_path}. Run scripts/build_cpp.sh first.")

    def solve(self, time_limit=None):
        return _run_binary(self.binary_path, self.instance, time_limit=time_limit)
