import subprocess
from pathlib import Path

class DPSolverCommon:
    def __init__(self, instance):
        self.instance = instance
        root = Path(__file__).resolve().parents[2]
        self.binary_path = root / "bin" / "dp_h_solver"
        if not self.binary_path.exists():
            raise FileNotFoundError(f"Binary not found at {self.binary_path}. Run scripts/build_cpp.sh first.")

    def solve(self, time_limit=None):
        input_str = f"{self.instance.n} {self.instance.s} {self.instance.d}\n"
        for job in self.instance.jobs:
            input_str += f"{job.p} {job.w}\n"

        try:
            process = subprocess.run(
                [str(self.binary_path)],
                input=input_str,
                text=True,
                capture_output=True,
                check=True,
                timeout=time_limit,
            )
            out = process.stdout.strip().split()
            if not out:
                return float("inf"), None
            val = float(out[0])
            states = int(out[1]) if len(out) > 1 else 0
            return val, states
        except subprocess.TimeoutExpired:
            return float("inf"), "TIME_LIMIT"
        except (subprocess.CalledProcessError, ValueError):
            return float("inf"), None
