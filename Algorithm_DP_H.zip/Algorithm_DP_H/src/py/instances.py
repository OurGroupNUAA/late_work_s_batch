
import random

class Job:
    def __init__(self, id, p, w, d=0):
        self.id = id
        self.p = p
        self.d = d
        self.w = w

    def __repr__(self):
        return f"J{self.id}(p={self.p}, w={self.w})"

class Instance:
    def __init__(self, jobs, s, d):
        self.jobs = jobs  # List of Job objects
        self.s = s        # Setup time
        self.n = len(jobs)
        self.d = d        # Common due date

class InstanceGenerator:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def generate_common_d_instance(self, n_jobs, s=1, p_range=(1, 10), w_range=(1, 10), tightness=0.5):
        """
        Generates a random instance with a common due date.
        """
        jobs = []
        for i in range(1, n_jobs + 1):
            p = self.rng.randint(*p_range)
            w = self.rng.randint(*w_range)
            jobs.append(Job(i, p, w))
        
        total_p = sum(j.p for j in jobs)
        common_d = int(total_p * tightness)
        
        return Instance(jobs, s=s, d=common_d)

    def generate_class_II_A(self, n, gamma):
        """
        Generates an instance based on Class II-A configuration (Trunk-line with Common Due Date).
        Parameters:
            n: Number of jobs (e.g., 100-500 for practical, 1000-5000 for stress)
            gamma: Due date tightness (0.5, 0.7, 0.9)
        Settings:
            s ~ U[300, 600]
            p_j ~ U[5, 15]
            w_j ~ U[1, 5]
            d = floor(gamma * sum(p_j))
        """
        s = self.rng.randint(300, 600)
        p_range = (5, 15)
        w_range = (1, 5)
        
        jobs = []
        for i in range(1, n + 1):
            p = self.rng.randint(*p_range)
            w = self.rng.randint(*w_range)
            jobs.append(Job(i, p, w))
            
        total_p = sum(j.p for j in jobs)
        common_d = int(total_p * gamma)
        
        return Instance(jobs, s=s, d=common_d)

# Legacy test instance
instance_2 = Instance([
    Job(1, 1, 4),
    Job(2, 1, 5),
    Job(3, 2, 2),
    Job(4, 3, 1)
], s=1, d=4)
