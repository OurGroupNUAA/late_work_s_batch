
import sys
try:
    import gurobipy as gp
    from gurobipy import GRB
except ImportError:
    gp = None
    GRB = None

def solve_gurobi_common_due_date(n, s, jobs, d, time_limit=300):
    if gp is None:
        return float('inf'), 'GUROBI_NOT_INSTALLED'
    """
    Solve 1|s-batch, d_j=d|Y_w using Gurobi.
    Corrected BigM to avoid Infeasibility.
    Structure: Optional Batch 1 (Early) + Optional Batch 2 (Straddling, 1 job) + Late.
    """
    try:
        # Create a new model
        m = gp.Model("BatchSchedulingCommonDueDate_Lemma3_Fixed")
        
        # Parameters
        m.setParam('TimeLimit', time_limit)
        m.setParam('OutputFlag', 0)
        m.setParam('Threads', 1)
        
        # Variables
        x = m.addVars(n, vtype=GRB.BINARY, name="x") # Batch 1
        y = m.addVars(n, vtype=GRB.BINARY, name="y") # Batch 2 (Straddle)
        z = m.addVars(n, vtype=GRB.BINARY, name="z") # Late
        
        u1 = m.addVar(vtype=GRB.BINARY, name="u1") # 1 if Batch 1 is used
        
        C1 = m.addVar(vtype=GRB.CONTINUOUS, lb=0.0, name="C1")
        V = m.addVars(n, vtype=GRB.CONTINUOUS, lb=0.0, name="V") # Cost for straddling
        
        # Constraints
        
        # 1. Partition
        m.addConstrs((x[j] + y[j] + z[j] == 1 for j in range(n)), name="Partition")
        
        # 2. Single Straddling Job
        m.addConstr(y.sum() <= 1, name="MaxOneStraddle")
        
        # 3. Batch 1 Logic
        for j in range(n):
            m.addConstr(x[j] <= u1, name=f"x_leq_u1_{j}")
            
        processing_x = gp.quicksum(jobs[j].p * x[j] for j in range(n))
        m.addConstr(C1 == s * u1 + processing_x, name="C1_Def")
        
        # 4. Batch 1 Early
        m.addConstr(C1 <= d, name="Batch1_Early")
        
        # 5. Straddling Cost
        # BigM needs to cover max possible weighted delay.
        # Max delay ~ (C1 + s + p) - d.
        # Max C1 ~ d.
        # Max term ~ d + s + p - d = s + p.
        # Wait, V_lb constraint: w * (C1 + s + p - d) - M(1-y).
        # We need M > w * (C1 + s + p - d) when y=0.
        # When y=0, C1 + s + p - d can be large?
        # C1 is determined by x.
        # If y=0, x takes some jobs.
        # Max C1 is d.
        # Max (C1 + s + p - d) <= d + s + p_max - d = s + p_max.
        # Max w = 5.
        # So M needs to be > 5 * (s + 15).
        # s ~ 600. M ~ 3000.
        # Let's be safe: M = max_w * (total_p + 2*s).
        
        max_w = max(job.w for job in jobs) if n > 0 else 1
        total_p = sum(job.p for job in jobs)
        BigM = max_w * (total_p + 2*s + 1000)
        
        for j in range(n):
            completion_term = C1 + s + jobs[j].p
            late_work_term = completion_term - d
            
            m.addConstr(V[j] >= jobs[j].w * late_work_term - BigM * (1 - y[j]), name=f"V_lb_{j}")
            m.addConstr(V[j] <= BigM * y[j], name=f"V_ub_y_{j}")
            m.addConstr(V[j] <= jobs[j].w * jobs[j].p, name=f"V_ub_p_{j}")
            
        # Objective
        obj_late = gp.quicksum(jobs[j].w * jobs[j].p * z[j] for j in range(n))
        obj_straddle = V.sum()
        
        m.setObjective(obj_late + obj_straddle, GRB.MINIMIZE)
        
        # Optimize
        m.optimize()
        
        if m.status in [GRB.OPTIMAL, GRB.TIME_LIMIT]:
            return m.objVal, "OPTIMAL" if m.status==GRB.OPTIMAL else "TIMEOUT"
        else:
            return float('inf'), f"ERR_{m.status}"
            
    except Exception as e:
        return float('inf'), f"EXC_{e}"
