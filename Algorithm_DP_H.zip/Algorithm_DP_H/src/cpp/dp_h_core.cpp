
#include <iostream>
#include <vector>
#include <algorithm>
#include <deque>

using namespace std;

typedef long long ll;
const ll INF = 1e18;

struct Job {
    int p, w;
};

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n, s, d;
    if (!(cin >> n >> s >> d)) return 0;
    vector<Job> jobs(n);
    ll total_w_p = 0;
    ll sum_p_val = 0;
    int max_p = 0;
    for (int i = 0; i < n; i++) {
        cin >> jobs[i].p >> jobs[i].w;
        total_w_p += (ll)jobs[i].w * jobs[i].p;
        sum_p_val += jobs[i].p;
        if (jobs[i].p > max_p) max_p = jobs[i].p;
    }

    int L_limit = (int)min((ll)d, sum_p_val);

    // pre[i][L] and suf[i][L] for fully early portions
    vector<ll> suf((ll)(n + 1) * (L_limit + 1), -1);
    auto s_idx = [&](int i, int L) { return (ll)i * (L_limit + 1) + L; };

    // Count generated reachable DP states (F-style), excluding manually initialized base states.
    long long total_states = 0;

    // Suf table calculation
    suf[s_idx(n, 0)] = 0;
    for (int i = n - 1; i >= 0; i--) {
        int pi = jobs[i].p;
        ll profit_i = (ll)jobs[i].w * pi;
        for (int L = 0; L <= L_limit; L++) {
            suf[s_idx(i, L)] = suf[s_idx(i + 1, L)];
            if (L >= pi) {
                ll next_val = suf[s_idx(i + 1, L - pi)];
                if (next_val != -1) {
                    suf[s_idx(i, L)] = max(suf[s_idx(i, L)], next_val + profit_i);
                }
            }
            if (suf[s_idx(i, L)] != -1) total_states++;
        }
    }

    ll best_objective = total_w_p;
    vector<ll> pre_curr(L_limit + 1, -1);
    pre_curr[0] = 0;
    long long pre_reachable_count = 1; // Base state pre[0][0], not counted yet.

    // We'll iterate through all prefix/suffix combinations for Case 3
    for (int i = 0; i < n; i++) {
        int pi = jobs[i].p;
        ll wi = jobs[i].w;

        // Case 3: Two batches, B1 early, B2 has only Ji and straddles.
        // Condition: 2s + L < d and 2s + L + pi > d, where L is early jobs length.
        int min_L3 = max(0, d - pi - 2*s + 1);
        int max_L3 = min(L_limit, d - 2*s - 1);

        if (min_L3 <= max_L3) {
            // Optimization logic
            // ...
            
            int current_upper = max_L3 - L_limit - 1; // last added index
            deque<int> dq; // Monotonic deque stores indices of Lb
            
            for (int La = L_limit; La >= 0; La--) {
                int L_lower = min_L3 - La;
                int L_upper = max_L3 - La;
                
                // Add new elements to window (up to L_upper)
                while (current_upper < L_upper) {
                    current_upper++;
                    if (current_upper > L_limit) break;
                    if (current_upper < 0) continue;
                    
                    if (suf[s_idx(i + 1, current_upper)] != -1) {
                        ll val = suf[s_idx(i + 1, current_upper)] - (ll)wi * current_upper;
                        while (!dq.empty()) {
                            int back_idx = dq.back();
                            ll back_val = suf[s_idx(i + 1, back_idx)] - (ll)wi * back_idx;
                            if (back_val <= val) dq.pop_back();
                            else break;
                        }
                        dq.push_back(current_upper);
                    }
                }
                
                // Remove elements strictly less than L_lower
                while (!dq.empty() && dq.front() < L_lower) {
                    dq.pop_front();
                }
                
                // Query
                if (pre_curr[La] != -1 && !dq.empty()) {
                    int best_Lb = dq.front();
                    ll best_suf_term = suf[s_idx(i + 1, best_Lb)] - (ll)wi * best_Lb;
                    
                    ll term_La = pre_curr[La] - (ll)wi * La;
                    ll combined = term_La + best_suf_term;
                    
                    ll current_obj = total_w_p + (ll)wi * (2*s - d) - combined;
                    if (current_obj < best_objective) best_objective = current_obj;
                }
            }
        }

        // Update pre_curr for job i (to be used by job i+1)
        ll profit_i = (ll)wi * pi;
        for (int L = L_limit; L >= pi; L--) {
            if (pre_curr[L - pi] != -1) {
                bool was_unreachable = (pre_curr[L] == -1);
                pre_curr[L] = max(pre_curr[L], pre_curr[L - pi] + profit_i);
                if (was_unreachable) pre_reachable_count++;
            }
        }
        // Count reachable states in the current prefix row pre[i+1][L].
        total_states += pre_reachable_count;
    }

    // Case 1: Single early batch. B1 ends at s + L <= d.
    for (int L = 0; L <= min(L_limit, d - s); L++) {
        if (pre_curr[L] != -1) {
            best_objective = min(best_objective, total_w_p - pre_curr[L]);
        }
    }

    // Case 2: Single straddling batch. B1 ends at s + L = d + Delta.
    // Each job j in B1 must satisfy pj > Delta.
    for (int delta = 1; delta < max_p; delta++) {
        int L_target = d + delta - s;
        if (L_target < 0 || L_target > sum_p_val) continue;

        // DP: find max sum wj(pj - delta) for pj > delta
        vector<ll> dp2(L_target + 1, -1);
        dp2[0] = 0;
        bool exists = false;
        long long dp2_reachable_count = 1; // Base state dp2[0], not counted yet.
        for (int j = 0; j < n; j++) {
            if (jobs[j].p > delta) {
                exists = true;
                int pj = jobs[j].p;
                ll profit = (ll)jobs[j].w * (pj - delta);
                for (int L = L_target; L >= pj; L--) {
                    if (dp2[L - pj] != -1) {
                        bool was_unreachable = (dp2[L] == -1);
                        dp2[L] = max(dp2[L], dp2[L - pj] + profit);
                        if (was_unreachable) dp2_reachable_count++;
                    }
                }
                // Count reachable states in the current dp2 row (for this eligible-job stage).
                total_states += dp2_reachable_count;
            }
        }
        if (exists && dp2[L_target] != -1) {
            best_objective = min(best_objective, total_w_p - dp2[L_target]);
        }
    }

    cout << (double)best_objective << " " << total_states << endl;
    return 0;
}
