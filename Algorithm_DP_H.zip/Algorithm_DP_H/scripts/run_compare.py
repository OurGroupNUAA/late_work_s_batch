#!/usr/bin/env python3
import argparse
import csv
import math
import subprocess
import time
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "py"))
sys.path.insert(0, str(ROOT / "src" / "gurobi"))

from instances import InstanceGenerator
from gurobi_solver_dp_h import solve_gurobi_common_due_date


def parse_int_list(raw):
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


def parse_float_list(raw):
    return [float(x.strip()) for x in raw.split(",") if x.strip()]


def gamma_tag(g):
    return f"g{g:g}"


def fmt_obj(x):
    try:
        xf = float(x)
        if math.isinf(xf):
            return "inf"
        return f"{xf:.6f}"
    except Exception:
        return str(x)


def run_dp(binary_path, inst, timeout):
    input_str = f"{inst.n} {inst.s} {inst.d}\n"
    for job in inst.jobs:
        input_str += f"{job.p} {job.w}\n"

    t0 = time.perf_counter()
    try:
        proc = subprocess.run(
            [str(binary_path)],
            input=input_str,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=True,
        )
        dt = time.perf_counter() - t0
        out = proc.stdout.strip().split()
        if len(out) >= 2:
            return float(out[0]), dt, int(out[1]), "OPTIMAL"
        if len(out) == 1:
            return float(out[0]), dt, 0, "BAD_OUTPUT"
        return float("inf"), dt, 0, "BAD_OUTPUT"
    except subprocess.TimeoutExpired:
        return float("inf"), float(timeout), 0, "TIMEOUT"
    except (subprocess.CalledProcessError, ValueError):
        return float("inf"), 0.0, 0, "ERROR"


def run_gurobi(inst, timeout):
    t0 = time.perf_counter()
    val, status = solve_gurobi_common_due_date(inst.n, inst.s, inst.jobs, inst.d, time_limit=timeout)
    dt = time.perf_counter() - t0
    return float(val), dt, str(status)


def write_instance_txt(path, instance_id, n, gamma, rep, seed, inst, dp_obj, grb_obj, dp_states, dp_status, grb_status, dp_time, grb_time):
    with path.open("w", encoding="utf-8") as f:
        f.write("# Reproducible instance for Algorithm_DP_H\n")
        f.write(f"instance_id: {instance_id}\n")
        f.write(f"n: {n}\n")
        f.write(f"gamma: {gamma}\n")
        f.write(f"s: {inst.s}\n")
        f.write(f"common_due_date: {inst.d}\n")
        f.write(f"rep: {rep}\n")
        f.write(f"seed: {seed}\n")
        f.write("\n")
        f.write("# Jobs (id p w)\n")
        for j in inst.jobs:
            f.write(f"{j.id} {j.p} {j.w}\n")
        f.write("\n")
        f.write("# Optimal objective values / solver status\n")
        f.write(f"obj_dp_h: {fmt_obj(dp_obj)}\n")
        f.write(f"obj_gurobi: {fmt_obj(grb_obj)}\n")
        f.write(f"time_dp_h: {dp_time:.6f}\n")
        f.write(f"time_gurobi: {grb_time:.6f}\n")
        f.write(f"dp_states_dp_h: {dp_states}\n")
        f.write(f"status_dp_h: {dp_status}\n")
        f.write(f"status_gurobi: {grb_status}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--seed-start", type=int, default=20260209)
    ap.add_argument("--n-list", type=str, default="100,200,300,400,500,1000,2000,3000,4000,5000")
    ap.add_argument("--gamma-list", type=str, default="0.5,0.7,0.9")
    args = ap.parse_args()

    n_list = parse_int_list(args.n_list)
    g_list = parse_float_list(args.gamma_list)

    dp_bin = ROOT / "bin" / "dp_h_solver"
    if not dp_bin.exists():
        raise FileNotFoundError(
            "Missing binary. Run scripts/build_cpp.sh\n"
            f"Expected: {dp_bin}"
        )

    raw_dir = ROOT / "results" / "raw"
    sum_dir = ROOT / "results" / "summary"
    inst_dir = ROOT / "results" / "instances_txt"
    raw_dir.mkdir(parents=True, exist_ok=True)
    sum_dir.mkdir(parents=True, exist_ok=True)
    inst_dir.mkdir(parents=True, exist_ok=True)
    detailed_path = raw_dir / "detailed.csv"
    summary_path = sum_dir / "table_dp_h_table_ready.csv"

    with detailed_path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "instance_id", "n", "gamma", "rep", "seed",
            "dp_h_obj", "gurobi_obj",
            "dp_h_time", "gurobi_time",
            "dp_h_states",
            "dp_h_status", "gurobi_status",
            "match_dp_h_vs_gurobi",
            "is_timeout",
        ])

    grouped = {}
    instance_id = 0

    for n in n_list:
        for gamma in g_list:
            key = (n, gamma)
            grb_t, dp_t, st = [], [], []
            failed = False

            for rep in range(1, args.repeats + 1):
                seed = args.seed_start + rep - 1
                gen = InstanceGenerator(seed=seed)
                inst = gen.generate_class_II_A(n, gamma)
                instance_id += 1

                dp_obj, dp_time, dp_states, dp_status = run_dp(dp_bin, inst, args.timeout)
                grb_obj, grb_time, grb_status = run_gurobi(inst, args.timeout)

                match = dp_status == "OPTIMAL" and grb_status == "OPTIMAL" and abs(dp_obj - grb_obj) <= 1e-6
                is_timeout = (
                    dp_status == "TIMEOUT" or grb_status in {"TIMEOUT", "TIME_LIMIT"}
                    or dp_time >= args.timeout or grb_time >= args.timeout
                )

                with detailed_path.open("a", newline="") as f:
                    w = csv.writer(f)
                    w.writerow([
                        instance_id, n, gamma, rep, seed,
                        dp_obj, grb_obj,
                        f"{dp_time:.6f}", f"{grb_time:.6f}",
                        dp_states,
                        dp_status, grb_status,
                        int(match),
                        int(is_timeout),
                    ])

                inst_txt_path = inst_dir / f"instance_{instance_id:04d}_n{n}_g{gamma}_rep{rep}.txt"
                write_instance_txt(
                    inst_txt_path, instance_id, n, gamma, rep, seed, inst,
                    dp_obj, grb_obj, dp_states, dp_status, grb_status, dp_time, grb_time
                )
                print(
                    f"Instance {instance_id} (n={n}, gamma={gamma}, rep={rep}, seed={seed}) "
                    f"-> obj: DP-H={fmt_obj(dp_obj)}, Gurobi={fmt_obj(grb_obj)} "
                    f"| status: DP-H={dp_status}, Gurobi={grb_status} | txt={inst_txt_path}"
                )

                if is_timeout or dp_status != "OPTIMAL" or grb_status != "OPTIMAL" or not match:
                    failed = True
                    break

                grb_t.append(grb_time)
                dp_t.append(dp_time)
                st.append(dp_states)

            grouped[key] = None if failed or len(grb_t) != args.repeats else (
                sum(grb_t) / len(grb_t),
                sum(dp_t) / len(dp_t),
                sum(st) / len(st),
            )

    with summary_path.open("w", newline="") as f:
        w = csv.writer(f)
        header = ["n"]
        for g in g_list:
            tag = gamma_tag(g)
            header.extend([f"CPU_Grb_{tag}", f"CPU_DP-H_{tag}", f"States_DP-H_{tag}"])
        w.writerow(header)
        for n in n_list:
            row = [n]
            for g in g_list:
                val = grouped.get((n, g))
                if val is None:
                    row.extend(["--", "--", "--"])
                else:
                    row.extend([f"{val[0]:.4f}", f"{val[1]:.4f}", f"{val[2]:.1f}"])
            w.writerow(row)

    print(f"Wrote: {detailed_path}")
    print(f"Wrote: {summary_path}")


if __name__ == "__main__":
    main()
