#!/usr/bin/env python3
import argparse
import csv
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "gurobi"))
from gurobi_solver_dp_h import solve_gurobi_common_due_date


@dataclass
class Job:
    p: int
    w: int


@dataclass
class InstanceRecord:
    path: Path
    file_name: str
    n: int
    gamma: float
    s: int
    d: int
    rep: int | None
    seed: int | None
    jobs: list[Job]


def parse_int(raw: str) -> int | None:
    try:
        return int(raw.strip())
    except Exception:
        return None


def parse_instance_txt(path: Path) -> InstanceRecord | None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    n_m = re.search(r"^n:\s*(\d+)\s*$", text, flags=re.M)
    g_m = re.search(r"^gamma:\s*([+-]?[0-9]+(?:\.[0-9]+)?)\s*$", text, flags=re.M)
    s_m = re.search(r"^s:\s*(\d+)\s*$", text, flags=re.M)
    d_m = re.search(r"^common_due_date:\s*(\d+)\s*$", text, flags=re.M)
    if d_m is None:
        d_m = re.search(r"^d:\s*(\d+)\s*$", text, flags=re.M)
    rep_m = re.search(r"^rep:\s*(\d+)\s*$", text, flags=re.M)
    seed_m = re.search(r"^seed:\s*(\d+)\s*$", text, flags=re.M)
    if not (n_m and g_m and s_m and d_m):
        return None

    n = int(n_m.group(1))
    gamma = float(g_m.group(1))
    s = int(s_m.group(1))
    d = int(d_m.group(1))
    rep = int(rep_m.group(1)) if rep_m else None
    seed = int(seed_m.group(1)) if seed_m else None

    lines = text.splitlines()
    jobs: list[Job] = []
    in_jobs = False
    for line in lines:
        x = line.strip()
        if not x:
            continue
        if x.startswith("# Jobs"):
            in_jobs = True
            continue
        if in_jobs and x.startswith("#"):
            break
        if in_jobs:
            parts = x.split()
            if len(parts) == 2:
                vals = [parse_int(parts[0]), parse_int(parts[1])]
            elif len(parts) >= 3:
                vals = [parse_int(parts[1]), parse_int(parts[2])]
            else:
                continue
            if None in vals:
                continue
            p, w = vals
            jobs.append(Job(p=p, w=w))

    if len(jobs) != n:
        return None

    return InstanceRecord(
        path=path,
        file_name=path.name,
        n=n,
        gamma=gamma,
        s=s,
        d=d,
        rep=rep,
        seed=seed,
        jobs=jobs,
    )


def format_obj(x: float) -> str:
    if x == float("inf"):
        return "inf"
    return f"{x:.6f}"


def update_txt_fields(path: Path, obj_value: float, status_value: str, time_value: float) -> None:
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    obj_line = f"obj_gurobi: {format_obj(obj_value)}"
    status_line = f"status_gurobi: {status_value}"
    time_line = f"time_gurobi: {time_value:.6f}"

    obj_idx = None
    status_idx = None
    time_idx = None
    for i, line in enumerate(lines):
        if line.startswith("obj_gurobi:"):
            obj_idx = i
        elif line.startswith("status_gurobi:"):
            status_idx = i
        elif line.startswith("time_gurobi:"):
            time_idx = i

    if obj_idx is not None:
        lines[obj_idx] = obj_line
    else:
        lines.append(obj_line)
    if status_idx is not None:
        lines[status_idx] = status_line
    else:
        lines.append(status_line)
    if time_idx is not None:
        lines[time_idx] = time_line
    else:
        lines.append(time_line)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def solve_one_instance(rec: InstanceRecord, effective_time_limit: int | None) -> tuple[float, str, float, int]:
    gurobi_limit = effective_time_limit if effective_time_limit is not None else 1_000_000_000
    t0 = time.perf_counter()
    obj, status = solve_gurobi_common_due_date(rec.n, rec.s, rec.jobs, rec.d, time_limit=gurobi_limit)
    run_t = time.perf_counter() - t0

    if status in {"TIMEOUT", "TIME_LIMIT"}:
        status = "TIME_LIMIT"
        if effective_time_limit is not None:
            run_t = min(run_t, float(effective_time_limit))
        is_timeout = 1
    else:
        is_timeout = 0
    return obj, status, run_t, is_timeout


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances-dir", type=str, default=str(ROOT / "results" / "instances_txt"))
    ap.add_argument("--glob", type=str, default="instance_*.txt", help="File glob under instances-dir.")
    ap.add_argument(
        "--time-limit",
        type=int,
        default=1800,
        help="Per-instance time limit in seconds. <=0 means no time limit.",
    )
    ap.add_argument("--raw-out", type=str, default=str(ROOT / "results" / "raw" / "gurobi_fill_detailed.csv"))
    ap.add_argument("--summary-out", type=str, default=str(ROOT / "results" / "summary" / "table_gurobi_only_table_ready.csv"))
    ap.add_argument("--backfill-txt", action="store_true", help="Write obj_gurobi/time_gurobi/status_gurobi back into instance txt files.")
    ap.add_argument("--quiet", action="store_true", help="Disable per-instance progress printing.")
    args = ap.parse_args()

    instances_dir = Path(args.instances_dir)
    raw_out = Path(args.raw_out)
    summary_out = Path(args.summary_out)
    raw_out.parent.mkdir(parents=True, exist_ok=True)
    summary_out.parent.mkdir(parents=True, exist_ok=True)

    records: list[InstanceRecord] = []
    bad_files = 0
    file_list = sorted(instances_dir.glob(args.glob))
    if not file_list and args.glob == "instance_*.txt":
        file_list = sorted(instances_dir.glob("*.txt"))
    for fp in file_list:
        rec = parse_instance_txt(fp)
        if rec is None:
            bad_files += 1
            continue
        records.append(rec)

    raw_header = [
        "instance_file",
        "n",
        "gamma",
        "s",
        "rep",
        "seed",
        "gurobi_obj",
        "gurobi_time",
        "gurobi_status",
        "is_timeout",
        "is_inferred",
        "reason",
    ]
    raw_rows: list[dict] = []
    total_instances = len(records)
    effective_time_limit = args.time_limit if args.time_limit > 0 else None
    actual_calls = 0
    actual_timeouts = 0
    ordered_records = sorted(records, key=lambda r: (r.n, r.gamma, (r.rep if r.rep is not None else 0), r.file_name))

    with raw_out.open("w", newline="", encoding="utf-8") as raw_f:
        raw_writer = csv.DictWriter(raw_f, fieldnames=raw_header)
        raw_writer.writeheader()
        raw_f.flush()

        for done_count, rec in enumerate(ordered_records, start=1):
            try:
                obj, status, run_t, is_timeout = solve_one_instance(rec, effective_time_limit)
            except Exception as exc:
                obj, status, run_t, is_timeout = float("inf"), f"ERROR_{type(exc).__name__}", 0.0, 0

            actual_calls += 1
            actual_timeouts += is_timeout

            if args.backfill_txt:
                update_txt_fields(rec.path, obj, status, run_t)

            row = {
                "instance_file": rec.file_name,
                "n": rec.n,
                "gamma": rec.gamma,
                "s": rec.s,
                "rep": rec.rep if rec.rep is not None else "",
                "seed": rec.seed if rec.seed is not None else "",
                "gurobi_obj": format_obj(obj),
                "gurobi_time": f"{run_t:.6f}",
                "gurobi_status": status,
                "is_timeout": is_timeout,
                "is_inferred": 0,
                "reason": "",
            }
            raw_rows.append(row)
            raw_writer.writerow(row)
            raw_f.flush()

            if not args.quiet:
                print(
                    f"[{done_count}/{total_instances}] file={rec.file_name} "
                    f"(n={rec.n}, gamma={rec.gamma}, s={rec.s}, rep={rec.rep}) "
                    f"-> status={status}, obj={format_obj(obj)}, time={run_t:.3f}s",
                    flush=True,
                )

    n_values = sorted({int(r["n"]) for r in raw_rows})
    g_values = sorted({float(r["gamma"]) for r in raw_rows})
    grouped: dict[tuple[int, float], list[dict]] = {}
    for r in raw_rows:
        key = (int(r["n"]), float(r["gamma"]))
        grouped.setdefault(key, []).append(r)

    summary_header = ["n", "gamma", "CPU_Grb", "TO_Grb", "Solved_Grb"]
    with summary_out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(summary_header)
        for n in n_values:
            for g in g_values:
                vals = grouped.get((n, g), [])
                if not vals:
                    w.writerow([n, g, "--", "--", "--"])
                    continue
                times = [float(v["gurobi_time"]) for v in vals]
                to_cnt = sum(1 for v in vals if v["gurobi_status"] in {"TIME_LIMIT", "TIMEOUT"})
                solved_cnt = sum(1 for v in vals if v["gurobi_status"] == "OPTIMAL")
                w.writerow([n, g, f"{sum(times)/len(times):.4f}", str(to_cnt), str(solved_cnt)])

    print(f"parsed_instances={len(records)}")
    print(f"bad_files_skipped={bad_files}")
    print(f"actual_calls={actual_calls}")
    print(f"actual_timeouts={actual_timeouts}")
    print(f"time_limit={'NONE' if effective_time_limit is None else effective_time_limit}")
    print(f"backfill_txt={int(args.backfill_txt)}")
    print(f"raw_out={raw_out}")
    print(f"summary_out={summary_out}")


if __name__ == "__main__":
    main()
