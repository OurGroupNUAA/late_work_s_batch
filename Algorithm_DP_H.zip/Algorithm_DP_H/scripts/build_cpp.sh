#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/bin"
g++ -O3 -std=c++17 "$ROOT/src/cpp/dp_h_core.cpp" -o "$ROOT/bin/dp_h_solver"
echo "Built DP-H binary in $ROOT/bin/dp_h_solver"
