#!/usr/bin/env python3
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "py"))
from instances import InstanceGenerator


def parse_int_list(raw: str):
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


def parse_float_list(raw: str):
    return [float(x.strip()) for x in raw.split(",") if x.strip()]


def write_instance_txt(path: Path, instance_id: int, n: int, gamma: float, rep: int, seed: int, inst):
    with path.open("w", encoding="utf-8") as f:
        f.write("# Reproducible instance for Algorithm_DP_H\n")
        f.write("# Result fields are placeholders; fill them after solving.\n")
        f.write(f"instance_id: {instance_id}\n")
        f.write(f"n: {n}\n")
        f.write(f"gamma: {gamma}\n")
        f.write(f"s: {inst.s}\n")
        f.write(f"common_due_date: {inst.d}\n")
        f.write("class: Class II-A\n")
        f.write(f"rep: {rep}\n")
        f.write(f"seed: {seed}\n")
        f.write("\n")
        f.write("# Jobs (id p w)\n")
        for j in inst.jobs:
            f.write(f"{j.id} {j.p} {j.w}\n")
        f.write("\n")
        f.write("# Optimal objective values / solver status\n")
        f.write("obj_dp_h: PENDING\n")
        f.write("obj_gurobi: PENDING\n")
        f.write("time_dp_h: PENDING\n")
        f.write("time_gurobi: PENDING\n")
        f.write("dp_states_dp_h: PENDING\n")
        f.write("status_dp_h: PENDING\n")
        f.write("status_gurobi: PENDING\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n-list", type=str, default="100,200,300,400,500,1000,2000,3000,4000,5000")
    ap.add_argument("--gamma-list", type=str, default="0.5,0.7,0.9")
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--seed-start", type=int, default=20260209)
    ap.add_argument("--out-dir", type=str, default=str(ROOT / "results" / "instances_txt"))
    ap.add_argument("--prefix", type=str, default="instance")
    ap.add_argument(
        "--clear-existing",
        action="store_true",
        help="Delete existing '<prefix>_*.txt' under out-dir before generation.",
    )
    args = ap.parse_args()

    n_list = parse_int_list(args.n_list)
    g_list = parse_float_list(args.gamma_list)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.clear_existing:
        for p in out_dir.glob(f"{args.prefix}_*.txt"):
            p.unlink()

    instance_id = 0
    for n in n_list:
        for gamma in g_list:
            for rep in range(1, args.repeats + 1):
                seed = args.seed_start + rep - 1
                gen = InstanceGenerator(seed=seed)
                inst = gen.generate_class_II_A(n, gamma=gamma)
                instance_id += 1
                out_name = f"{args.prefix}_{instance_id:04d}_n{n}_g{gamma}_rep{rep}.txt"
                out_path = out_dir / out_name
                write_instance_txt(out_path, instance_id, n, gamma, rep, seed, inst)
                print(f"Generated instance {instance_id} (n={n}, gamma={gamma}, rep={rep}, seed={seed}) -> txt={out_path}")

    print(f"Wrote {instance_id} instances to: {out_dir}")


if __name__ == "__main__":
    main()
