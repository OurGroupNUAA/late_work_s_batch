# Algorithm_DP_H

This folder contains Class-II-A benchmark experiments comparing `DP-H` (C++) and `Gurobi`.

## Directory Layout

- `scripts/`: instance generation, batch solve, and comparison scripts
- `src/`: DP-H and Gurobi implementations
- `bin/`: compiled `dp_h_solver`
- `results/`: instance text files, detailed outputs, and summary tables

## Environment

Run in this directory:

```bash
source ../.venv_all_algorithms/bin/activate
python -c "import gurobipy as gp; print(gp.gurobi.version())"
```

## Build (C++)

```bash
bash scripts/build_cpp.sh
```

Output:

- `bin/dp_h_solver`

## Usage 1: One-Command Comparison (Recommended)

```bash
python scripts/run_compare.py --repeats 10 --timeout 1800
```

This script will:

- generate instances from the parameter grid
- run `DP-H` and `Gurobi` on each instance
- write instance files, detailed results, and summary tables

Main outputs:

- `results/instances_txt/`
- `results/raw/detailed.csv`
- `results/summary/table_dp_h_table_ready.csv`

## Usage 2: Run Step-by-Step (Reuse Existing Instances)

### 1. Generate instances

```bash
python scripts/generate_classIIA_instances_random.py --clear-existing
```

Output directory: `results/instances_txt/`

### 2. Run DP-H only

```bash
python scripts/DPH_solve_instances.py --backfill-txt
```

Outputs:

- `results/raw/dp_h_fill_detailed.csv`
- `results/summary/table_dp_h_only_table_ready.csv`

### 3. Run Gurobi only

```bash
python scripts/Gurobi_solve_instances.py --backfill-txt
```

Outputs:

- `results/raw/gurobi_fill_detailed.csv`
- `results/summary/table_gurobi_only_table_ready.csv`

## Common Options

`run_compare.py`:

- `--repeats 10`: number of repetitions per parameter group
- `--timeout 1800`: per-instance timeout in seconds
- `--n-list ...` / `--gamma-list ...`: custom parameter grid

`DPH_solve_instances.py` / `Gurobi_solve_instances.py`:

- `--time-limit 1800`: per-instance time limit in seconds
- `--time-limit <=0`: no time limit
- `--backfill-txt`: write solver results back into instance text files
- `--quiet`: disable per-instance progress output

Only available in `DPH_solve_instances.py`:

- `--max-unsolved-per-n-gamma 3`: skip the remaining instances in a `(n, gamma)` group after too many unsolved cases (`<0` disables this)

## Output and Rule Notes

- Step-by-step scripts read `results/instances_txt/instance_*.txt`
- `raw/*.csv` stores per-instance details; `summary/*.csv` stores table-ready summaries
- Timeout statuses are normalized to `TIME_LIMIT`
- In `run_compare.py`, if any repetition in a `(n, gamma)` group times out, is non-optimal, or produces a mismatch, that group is written as `--` in the summary table
