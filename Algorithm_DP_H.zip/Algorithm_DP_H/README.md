# Algorithm_DP_H

Self-contained folder for DP-H experiments (C++ DP + Gurobi comparison).

## Environment
```bash
source ../.venv_all_algorithms/bin/activate
python -c "import gurobipy as gp; print(gp.gurobi.version())"
```

## Build
```bash
bash scripts/build_cpp.sh
```

## Run
```bash
python scripts/run_compare.py --repeats 10 --timeout 1800
```

## Generate Instances Only
```bash
python scripts/generate_classIIA_instances_random.py --clear-existing
```
This writes reproducible instances to `results/instances_txt` with `PENDING` placeholders.

## Solve Existing Instances (DP-H Only)
```bash
python scripts/DPH_solve_instances.py --backfill-txt
```
This reads `results/instances_txt/instance_*.txt`, runs `bin/dp_h_solver`, and writes:
- Raw detail: `results/raw/dp_h_fill_detailed.csv`
- Summary: `results/summary/table_dp_h_only_table_ready.csv`

## Solve Existing Instances (Gurobi Only)
```bash
python scripts/Gurobi_solve_instances.py --backfill-txt
```
This reads `results/instances_txt/instance_*.txt`, runs `src/gurobi/gurobi_solver_dp_h.py`, and writes:
- Raw detail: `results/raw/gurobi_fill_detailed.csv`
- Summary: `results/summary/table_gurobi_only_table_ready.csv`

## Outputs
- Raw detail: `results/raw/detailed.csv`
- Table-ready summary: `results/summary/table_dp_h_table_ready.csv`

Rule: if any repetition in a parameter group times out (DP-H or Gurobi), that group is marked as `--` in summary.
