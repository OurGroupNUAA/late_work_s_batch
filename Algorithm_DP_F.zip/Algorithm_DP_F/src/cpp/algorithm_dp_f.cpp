#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <tuple>
#include <set>
#include <limits>

using namespace std;

const long long INF = 1e18; // Use a large number for infinity

#ifndef ENABLE_PRECALC_43
#define ENABLE_PRECALC_43 1
#endif

struct Job {
    int id;
    int p, d, w;
};

// Sort by EDD
bool compareJobs(const Job& a, const Job& b) {
    if (a.d != b.d) return a.d < b.d;
    return a.id < b.id;
}

// Global data
int n, s;
vector<Job> jobs;
vector<int> p_min_suffix; // p_min^(j)
vector<int> P_suffix;     // P^(j)

// Stat Counting
long long total_states = 0;

// State Definition
using Key1 = tuple<int, int, int, int>; // L1, t1, ud, bd
using Key2 = tuple<int, int, int, int, int, int, int>; // L1, t1, ud, bd, L2, t2, k

// Mapping state to value
long long f_next_0 = 0;
map<Key1, long long> f_next_1;
vector<map<Key2, long long>> f_next_b; 

long long f_curr_0 = INF;
map<Key1, long long> f_curr_1;
vector<map<Key2, long long>> f_curr_b;
vector<int> active_next_b, active_curr_b;
vector<char> in_active_next_b, in_active_curr_b;

inline void mark_active_curr_b(int b) {
    if (!in_active_curr_b[b]) {
        in_active_curr_b[b] = 1;
        active_curr_b.push_back(b);
    }
}

inline void relax_key1(map<Key1, long long>& mp, const Key1& key, long long val) {
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(key, val);
        total_states++;
    }
    else if (val < it->second) it->second = val;
}

inline void relax_key2(int b, const Key2& key, long long val) {
    auto& mp = f_curr_b[b];
    auto it = mp.find(key);
    if (it == mp.end()) {
        mp.emplace(key, val);
        mark_active_curr_b(b);
        total_states++;
    } else if (val < it->second) {
        it->second = val;
    }
}

template <typename K>
inline void relax_min_map(map<K, long long>& mp, const K& key, long long val) {
    auto it = mp.find(key);
    if (it == mp.end()) mp.emplace(key, val);
    else if (val < it->second) it->second = val;
}

void clean_maps() {
    f_curr_0 = INF;
    f_curr_1.clear();
    if (f_curr_b.size() != n + 1) f_curr_b.resize(n + 1);
    for (int b : active_curr_b) {
        f_curr_b[b].clear();
        in_active_curr_b[b] = 0;
    }
    active_curr_b.clear();
}

void swap_maps() {
    f_next_0 = f_curr_0;
    f_next_1.swap(f_curr_1);
    f_next_b.swap(f_curr_b);
    active_next_b.swap(active_curr_b);
    in_active_next_b.swap(in_active_curr_b);
    if(f_next_b.size() != n + 1) f_next_b.resize(n + 1);
    if(f_curr_b.size() != n + 1) f_curr_b.resize(n + 1);
}

int main() {
    /* if (freopen("input.txt", "r", stdin) == NULL) {
    } */

    if (!(cin >> n >> s)) return 0;
    jobs.resize(n);
    for (int i = 0; i < n; ++i) {
        jobs[i].id = i + 1;
        cin >> jobs[i].p >> jobs[i].d >> jobs[i].w;
    }

    sort(jobs.begin(), jobs.end(), compareJobs);
    
    // Calculate total P for horizon
    long long total_P = 0;
    for(const auto& job : jobs) total_P += job.p;
    long long horizon = (long long)n * s + total_P;

    f_curr_b.resize(n + 1);
    in_active_next_b.assign(n + 1, 0);
    in_active_curr_b.assign(n + 1, 0);

    // Precompute Min P Suffix and Sum P Suffix
    p_min_suffix.assign(n + 2, 0);
    P_suffix.assign(n + 2, 0);
    int current_min_p = 2000000000;
    int current_sum_p = 0;
    for (int j = n; j >= 1; --j) {
        current_min_p = min(current_min_p, jobs[j-1].p);
        current_sum_p += jobs[j-1].p;
        p_min_suffix[j] = current_min_p;
        P_suffix[j] = current_sum_p;
    }

    // Initialization
    f_next_0 = 0;
    f_next_1[{0, 0, 0, 0}] = 0;
    f_next_b.resize(n + 1);

    // Main Loop j = n to 1
    for (int j = n; j >= 1; --j) {
        Job J = jobs[j-1]; // Current job
        int jobs_processed = n - j + 1;
        clean_maps();

        // 1. Pre-calculation for Subcase 2.2:
        // \tilde{f}_{j+1}^1(L1, t1, bd) = min_{ud' <= bd} f_{j+1}^1(L1, t1, ud', bd)
        map<tuple<int,int,int>, long long> tilde_f1_22;
        for (auto const& [key, val] : f_next_1) {
            auto [l1, t1, ud, bd] = key;
            tuple<int,int,int> aux_key = {l1, t1, bd};
            relax_min_map(tilde_f1_22, aux_key, val);
        }

        // 2. Pre-calculation for Subcase 3.2, 4.2:
        // \tilde{f}_{j+1}^b(L1, t1, bd, L2, t2, k) = min_{ud' <= bd} f_{j+1}^b(...)
        vector<map<tuple<int,int,int,int,int,int>, long long>> tilde_fb_x2(n + 1);
        for (int b : active_next_b) {
            if (b > jobs_processed) continue;
            for (auto const& [key, val] : f_next_b[b]) {
                auto [l1, t1, ud, bd, l2, t2, k] = key;
                tuple<int,int,int,int,int,int> aux_key = {l1, t1, bd, l2, t2, k};
                relax_min_map(tilde_fb_x2[b], aux_key, val);
            }
        }

        // 3. Aux for Subcase 4.3 (Grouping)
        vector< map< pair<int,int>, vector<tuple<int,int,int,int,int,long long>> > > grouped_by_L1T1(n + 1);
        // Pre-calculation buckets for Subcase 4.6 (k' = 0 only):
        // key: (L1, t1, ud, bd), value list: (max_t2, val)
        vector< map<tuple<int,int,int,int>, vector<pair<int,long long>>> > precalc_46(n + 1);
        for(int b : active_next_b) {
            if (b > jobs_processed) continue;
            for(auto const& [key, val] : f_next_b[b]) {
                auto [l1, t1, ud, bd, l2, t2, k] = key;
                grouped_by_L1T1[b][{l1, t1}].emplace_back(ud, bd, l2, t2, k, val);
                if (k == 0) {
                    // Subcase 4.6 feasibility on inserted B2 completion:
                    // t2_new + s <= start(B3 processing) = t2' - L2'
                    // => t2_new <= t2' - L2' - s
                    long long mx_ll = (long long)t2 - l2 - 1LL * s;
                    if (mx_ll >= numeric_limits<int>::min() && mx_ll <= numeric_limits<int>::max()) {
                        precalc_46[b][{l1, t1, ud, bd}].emplace_back((int)mx_ll, val);
                    }
                }
            }
        }
        
        map< pair<int,int>, vector<tuple<int,int,long long>> > grouped_1_by_L1T1;
        for(auto const& [key, val] : f_next_1) {
            auto [l1, t1, ud, bd] = key;
            grouped_1_by_L1T1[{l1, t1}].emplace_back(ud, bd, val);
        }

        // --- DP TRANSITION ---

        // CASE 1: b=0
        if (f_next_0 != INF) {
             f_curr_0 = f_next_0 + (long long)J.w * J.p;
        }

        // CASE 2: b=1
        // Subcase 2.1: Late
        for (auto const& [key, val] : f_next_1) {
             long long cost = val + (long long)J.w * J.p;
             relax_key1(f_curr_1, key, cost);
        }

        // Subcase 2.2: J_j in B_1 (with others)
        for (auto const& [aux_key, val] : tilde_f1_22) {
            auto [l1_prev, t1, bd] = aux_key;
            if (l1_prev < p_min_suffix[j+1]) continue;
            if (t1 >= J.d + J.p) continue;
            
            Key1 new_key = {l1_prev + J.p, t1, J.d, bd};
            long long add_cost = (long long)J.w * max(0, t1 - J.d);
            long long total_cost = val + add_cost;
            relax_key1(f_curr_1, new_key, total_cost);
        }

        // Subcase 2.3: J_j is ONLY job in B_1
        if (f_next_0 != INF) {
            // FIX: Iterate up to horizon
            long long max_t1 = horizon; 
            long long limit_t1 = min(max_t1, (long long)J.d + J.p - 1LL);
            
            for (long long t = s + J.p; t <= limit_t1; ++t) {
                Key1 new_key = {J.p, (int)t, J.d, J.d};
                long long cost = f_next_0 + (long long)J.w * max(0LL, t - J.d);
                relax_key1(f_curr_1, new_key, cost);
            }
        }


        // CASE b >= 2
        set<int> b_to_process;
        if (!f_next_1.empty() && jobs_processed >= 2) b_to_process.insert(2);
        for (int b : active_next_b) {
            if (b <= jobs_processed) b_to_process.insert(b);
            if (b + 1 <= jobs_processed) b_to_process.insert(b + 1);
        }

        for (int b : b_to_process) {
            // Subcase X.1: Late
            for (auto const& [key, val] : f_next_b[b]) {
                long long cost = val + (long long)J.w * J.p;
                relax_key2(b, key, cost);
            }
            
            // Subcase X.2: J_j in B_1 (with others)
            for (auto const& [aux_key, val] : tilde_fb_x2[b]) {
                auto [l1_prev, t1, bd, l2, t2, k] = aux_key;
                if (l1_prev < p_min_suffix[j+1]) continue;
                if (t1 >= J.d + J.p) continue;
                
                Key2 new_key = {l1_prev + J.p, t1, J.d, bd, l2, t2, k};
                long long cost = val + (long long)J.w * max(0, t1 - J.d);
                relax_key2(b, new_key, cost);
            }

            // Subcase 3.5/3.6 and 4.4/4.5:
            // J_j is non-late in B2 and B2 already contains at least one job from J^(j+1).
            // Recurrence source keeps (L1,t1,ud,bd,t2) and uses L2' = L2 - p_j with k' range:
            // - if bd > d_j then new k=2 and k' in {0,1,2}
            // - if bd = d_j then new k=1 and k' in {0,1}
            for (auto const& [key, val] : f_next_b[b]) {
                auto [l1, t1, ud, bd, l2_prev, t2, k_prev] = key;

                // Need at least one other job already in B2.
                if (l2_prev < p_min_suffix[j + 1]) continue;
                // J_j must be non-late in B2.
                if (t2 >= J.d + J.p) continue;

                int k_new = -1;
                if (bd > J.d) {
                    // Disturbed in B2: k' can be 0/1/2.
                    k_new = 2;
                } else if (bd == J.d) {
                    // Semi-disturbed in B2: k' can be 0/1.
                    if (k_prev > 1) continue;
                    k_new = 1;
                } else {
                    // EDD order should make this practically impossible here.
                    continue;
                }

                int l2_new = l2_prev + J.p;
                // State feasibility: B2 completion cannot be earlier than its own processing window after B1.
                if ((long long)t2 < (long long)t1 + s + l2_new) continue;

                Key2 new_key = {l1, t1, ud, bd, l2_new, t2, k_new};
                long long cost = val + (long long)J.w * max(0, t2 - J.d);
                relax_key2(b, new_key, cost);
            }
            
            // Subcase X.3 / 4.3 (New B_1 = J_j, Old B_1 -> B_2) [Small before Large]
            
            if (b == 2) {
                 for (auto const& [next_pair, list] : grouped_1_by_L1T1) {
                    int l2_new = next_pair.first;
                    int t2_new = next_pair.second;
                    
                    long long max_t1 = (long long)t2_new - s - l2_new;
                    long long min_t1 = s + J.p;
                    if (max_t1 < min_t1) continue;
                    
                    long long limit = min(max_t1, (long long)J.d + J.p - 1LL);
#if ENABLE_PRECALC_43
                    // Pre-calculate minima by induced k_new (equivalent to minimizing over ud',bd').
                    long long best_k[3] = {INF, INF, INF};
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, val] = entry;
                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1; 
                        else k_new = 2;
                        best_k[k_new] = min(best_k[k_new], val);
                    }

                    for (int k_new = 0; k_new <= 2; ++k_new) {
                        if (best_k[k_new] == INF) continue;
                        for (long long t = min_t1; t <= limit; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = best_k[k_new] + (long long)J.w * max(0LL, t - J.d);
                            relax_key2(b, new_key, cost);
                        }
                    }
#else
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, val] = entry;

                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1;
                        else k_new = 2;

                        for (long long t = min_t1; t <= limit; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = val + (long long)J.w * max(0LL, t - J.d);
                            relax_key2(b, new_key, cost);
                        }
                    }
#endif
                 }
                 
                 // Subcase 3.7: J_j in B_2 (Result b=2). Source f_next_1 (b=1).
                 // B1 is preserved from suffix. B2 is J_j.
                 for (auto const& [key, val] : f_next_1) {
                    auto [l1_prev, t1, ud, bd] = key;
                    // B1 = (l1_prev, t1).
                    // B2 = {J_j}. L2=p_j.
                    // t2 range?
                    // t2 >= t1 + s + p_j.
                    // t2 < d_j + p_j.
                    // k?
                    // d(B1) range [ud, bd].
                    // k depends on d(B2)=d_j relative to B1.
                    // Wait. k is "relation of B2 jobs to B1 range".
                    // B2 has J_j.
                    // is d_j > bd? (Non-disturbed).
                    // is d_j == bd? (Semi).
                    // is d_j < bd? (Disturbed).
                    int k_new = 0;
                    if (J.d > bd) k_new = 0;
                    else if (J.d == bd) k_new = 1;
                    else k_new = 2;
                    
                    // Paper 3.7 constraints: "k=2 and bd > d_j OR k=1 and bd=d_j".
                    // So k=0 is NOT allowed?
                    // "Note k=0 because there is no disturbed job for schedule containing only one non-late batch." (In Previous step).
                    // Here we CREATE k.
                    // If k=0, it means d_j > bd.
                    // Lemma 2: J_large in B1, J_small in B2.
                    // d_j > bd implies J_j (B2) is LARGER than B1.
                    // This is "Large after Small".
                    // Lemma 2 allows this? "If d_i <= d_j".
                    // If J_j is large w.r.t B1 jobs.
                    // Then J_small in B1. J_large in B2.
                    // $J_{small} \in B_1 (k=1)$. $J_{large} \in B_2 (q=2)$.
                    // $1 \le 2+1$. Allowed.
                    // But Subcase 3.7 text specifically mentions k=1, 2.
                    // "If ... ((k=2 and bd > d_j) or (k=1 and bd=d_j))".
                    // Does it forbid k=0?
                    // Technically J_j is small (index j < index suffix).
                    // So d_j <= d(suffix jobs).
                    // So d_j <= ud <= bd.
                    // So d_j > bd is IMPOSSIBLE if sorted EDD.
                    // So k=0 is impossible.
                    
                    long long min_t2 = (long long)t1 + s + J.p;
                    long long max_t2 = min(horizon, (long long)J.d + J.p - 1LL);
                    
                    if (min_t2 > max_t2) continue;
                    
                    for(long long t2 = min_t2; t2 <= max_t2; ++t2) {
                        Key2 new_key = {l1_prev, t1, ud, bd, J.p, (int)t2, k_new};
                        long long cost = val + (long long)J.w * max(0LL, t2 - J.d);
                        relax_key2(b, new_key, cost);
                    }
                 }

            } else {
                 // b >= 3
                 // Subcase 4.3 (Small before Large)
                 for (auto const& [next_pair, list] : grouped_by_L1T1[b-1]) {
                    int l2_new = next_pair.first;
                    int t2_new = next_pair.second;
                     
                    long long max_t1 = (long long)t2_new - s - l2_new;
                    long long min_t1 = s + J.p;
                    if (max_t1 < min_t1) continue;
                    
                    long long limit = min(max_t1, (long long)J.d + J.p - 1LL);
#if ENABLE_PRECALC_43
                    // Pre-calculate minima by induced k_new with original feasibility filter.
                    long long best_k[3] = {INF, INF, INF};
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, l3, t3, k_next, val] = entry;

                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1;
                        else k_new = 2;

                        if (k_new == 2 && k_next != 0) continue;
                        best_k[k_new] = min(best_k[k_new], val);
                    }

                    for (int k_new = 0; k_new <= 2; ++k_new) {
                        if (best_k[k_new] == INF) continue;
                        for (long long t = min_t1; t <= limit; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = best_k[k_new] + (long long)J.w * max(0LL, t - J.d);
                            relax_key2(b, new_key, cost);
                        }
                    }
#else
                    for (auto const& entry : list) {
                        auto [ud_next, bd_next, l3, t3, k_next, val] = entry;

                        int k_new = 0;
                        if (ud_next > J.d) k_new = 0;
                        else if (ud_next == J.d) k_new = 1;
                        else k_new = 2;

                        if (k_new == 2 && k_next != 0) continue;

                        for (long long t = min_t1; t <= limit; ++t) {
                            Key2 new_key = {J.p, (int)t, J.d, J.d, l2_new, t2_new, k_new};
                            long long cost = val + (long long)J.w * max(0LL, t - J.d);
                            relax_key2(b, new_key, cost);
                        }
                    }
#endif
                 }
                 
                 // Subcase 4.6 (Large before Small)
                 // J_j inserted in B2. B1 preserved.
                 // Source: f_next_{b-1}. (b-1 must be >= 2 for B1, B2 to exist... Wait.)
                 // If suffix has b-1 batches. B1 is suffix B1.
                 // B2 is J_j.
                 // B3 is suffix B2.
                 // We need to fit J_j between B1 and B3.
                 // Query f_next_{b-1} grouped by (L1, t1).
                 // For each (L1, t1) group, we have list of (ud, bd, L2_suffix, t2_suffix, k_suffix).
                 // Here L2_suffix is start of B3 (relative to B1).
                 // Wait. Suffix B2 is our B3.
                 // Start of Suffix B2 processing: t2_suffix - L2_suffix.
                 // We need one setup between inserted B2 and suffix B2.
                 // So t2_new + s <= t2_suffix - L2_suffix.
                 // t2_new <= t2_suffix - L2_suffix - s.
                 // Also t2_new >= t1 + s + p_j.
                 
                 for (auto const& [k46, list] : precalc_46[b-1]) {
                    auto [l1_prev, t1_prev, ud, bd] = k46;
                    // B1 preserved.
                    // k for current state in Subcase 4.6 must be 1 (semi) or 2 (disturbed).
                    int k_new = -1;
                    if (J.d == bd) k_new = 1;
                    else if (J.d < bd) k_new = 2;
                    else continue; // J_j cannot be non-disturbed in Subcase 4.6.

                    long long min_t2_ll = (long long)t1_prev + s + J.p;
                    long long max_t2_ll = min((long long)J.d + J.p - 1LL, horizon);
                    if (min_t2_ll > max_t2_ll) continue;

                    int min_t2 = (int)min_t2_ll;
                    int max_t2 = (int)max_t2_ll;

                    // Sort by max_t2 descending, then sweep t2 descending to maintain suffix minimum.
                    vector<pair<int,long long>> cand = list;
                    sort(cand.begin(), cand.end(), [](const auto& a, const auto& b) {
                        if (a.first != b.first) return a.first > b.first;
                        return a.second < b.second;
                    });

                    long long best_val = INF;
                    size_t ptr = 0;
                    for (int t2 = max_t2; t2 >= min_t2; --t2) {
                        while (ptr < cand.size() && cand[ptr].first >= t2) {
                            best_val = min(best_val, cand[ptr].second);
                            ++ptr;
                        }
                        if (best_val == INF) continue;

                        Key2 new_key = {l1_prev, t1_prev, ud, bd, J.p, t2, k_new};
                        long long cost = best_val + (long long)J.w * max(0LL, (long long)t2 - J.d);
                        relax_key2(b, new_key, cost);
                    }
                 }
            }

        } // end b loop

        swap_maps();
    } // end j loop

    // Final result
    long long ans = INF;
    if (f_next_0 != INF) ans = min(ans, f_next_0);
    
    for (auto const& [key, val] : f_next_1) {
        auto [l1, t1, ud, bd] = key;
        if (t1 == s + l1) {
             ans = min(ans, val);
        }
    }
    
    // Check f_next_b
    if (n >= 2 && in_active_next_b[2]) {
        for (auto const& [key, val] : f_next_b[2]) {
             auto [l1, t1, ud, bd, l2, t2, k] = key;
             if (t1 == s + l1 && t2 == t1 + s + l2) {
                 ans = min(ans, val);
             }
        }
    }

    for (int b : active_next_b) {
        if (b < 3) continue;
        for (auto const& [key, val] : f_next_b[b]) {
             auto [l1, t1, ud, bd, l2, t2, k] = key;
             if (t1 == s + l1 && t2 == t1 + s + l2) {
                 ans = min(ans, val);
             }
        }
    }

    cout << ans << " " << total_states << endl;

    return 0;
}
