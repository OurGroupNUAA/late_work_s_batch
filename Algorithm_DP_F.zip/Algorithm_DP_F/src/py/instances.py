import math
import random


class Job:
    def __init__(self, job_id, p, d, w):
        self.id = job_id
        self.p = p
        self.d = d
        self.w = w

    def __repr__(self):
        return f"J{self.id}(p={self.p}, d={self.d}, w={self.w})"


class Instance:
    def __init__(self, jobs, s):
        self.jobs = jobs
        self.s = s
        self.n = len(jobs)


class InstanceGenerator:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def generate_class_I_instance(
        self,
        n,
        gamma,
        s=None,
        p_range=(5, 15),
        w_range=(1, 5),
        delta=30,
        s_choices=(5, 10, 15),
    ):
        if s is None:
            s = self.rng.choice(list(s_choices))
        p_list = [self.rng.randint(*p_range) for _ in range(n)]
        w_list = [self.rng.randint(*w_range) for _ in range(n)]

        k = max(1, math.ceil((gamma * sum(p_list)) / delta))
        d_choices = [i * delta for i in range(1, k + 1)]

        jobs = [Job(i + 1, p_list[i], self.rng.choice(d_choices), w_list[i]) for i in range(n)]
        return Instance(jobs, s)
