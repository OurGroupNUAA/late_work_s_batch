#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/bin"

built=()

if [[ -f "$ROOT/src/cpp/algorithm_dp_f.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f.cpp" -o "$ROOT/bin/algorithm_dp_f"
  built+=("$ROOT/bin/algorithm_dp_f")
fi

if [[ -f "$ROOT/src/cpp/algorithm_dp_f_speedup_dpg_ub_pmtn_lb.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_speedup_dpg_ub_pmtn_lb.cpp" -o "$ROOT/bin/algorithm_dp_f_speedup_dpg_ub_pmtn_lb"
  built+=("$ROOT/bin/algorithm_dp_f_speedup_dpg_ub_pmtn_lb")
fi

# Legacy optional variants (compile only when source exists).
if [[ -f "$ROOT/src/cpp/algorithm_dp_f_speedup.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_speedup.cpp" -o "$ROOT/bin/algorithm_dp_f_speedup"
  built+=("$ROOT/bin/algorithm_dp_f_speedup")
fi
if [[ -f "$ROOT/src/cpp/algorithm_dp_f_speedup_dpg_ub.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_speedup_dpg_ub.cpp" -o "$ROOT/bin/algorithm_dp_f_speedup_dpg_ub"
  built+=("$ROOT/bin/algorithm_dp_f_speedup_dpg_ub")
fi
if [[ -f "$ROOT/src/cpp/algorithm_dp_f_exact_subset.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_exact_subset.cpp" -o "$ROOT/bin/algorithm_dp_f_exact_subset"
  built+=("$ROOT/bin/algorithm_dp_f_exact_subset")
fi
if [[ -f "$ROOT/src/cpp/algorithm_dp_f_speedup_v2.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_speedup_v2.cpp" -o "$ROOT/bin/algorithm_dp_f_speedup_v2"
  built+=("$ROOT/bin/algorithm_dp_f_speedup_v2")
fi
if [[ -f "$ROOT/src/cpp/algorithm_dp_f_speedup_dominance.cpp" ]]; then
  g++ -O3 -std=c++17 "$ROOT/src/cpp/algorithm_dp_f_speedup_dominance.cpp" -o "$ROOT/bin/algorithm_dp_f_speedup_dominance"
  built+=("$ROOT/bin/algorithm_dp_f_speedup_dominance")
fi

if [[ "${#built[@]}" -eq 0 ]]; then
  echo "No DP-F C++ source files found under $ROOT/src/cpp"
  exit 1
fi

echo "Built DP-F binaries:"
for b in "${built[@]}"; do
  echo "  - $b"
done
