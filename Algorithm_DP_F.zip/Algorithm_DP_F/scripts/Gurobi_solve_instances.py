#!/usr/bin/env python3
import argparse
import concurrent.futures
import csv
import re
import time
from dataclasses import dataclass
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "gurobi"))
from gurobi_solver_dp_f import solve_gurobi_generic


@dataclass
class Job:
    p: int
    d: int
    w: int


@dataclass
class InstanceRecord:
    path: Path
    file_name: str
    n: int
    gamma: float
    s: int
    rep: int | None
    seed: int | None
    jobs: list[Job]


def parse_int(raw: str) -> int | None:
    try:
        return int(raw.strip())
    except Exception:
        return None


def parse_float(raw: str) -> float | None:
    try:
        return float(raw.strip())
    except Exception:
        return None


def parse_instance_txt(path: Path) -> InstanceRecord | None:
    text = path.read_text(encoding="utf-8", errors="ignore")
    n_m = re.search(r"^n:\s*(\d+)\s*$", text, flags=re.M)
    g_m = re.search(r"^gamma:\s*([0-9]+(?:\.[0-9]+)?)\s*$", text, flags=re.M)
    s_m = re.search(r"^s:\s*(\d+)\s*$", text, flags=re.M)
    rep_m = re.search(r"^rep:\s*(\d+)\s*$", text, flags=re.M)
    seed_m = re.search(r"^seed:\s*(\d+)\s*$", text, flags=re.M)
    if not (n_m and g_m and s_m):
        return None

    n = int(n_m.group(1))
    gamma = float(g_m.group(1))
    s = int(s_m.group(1))
    rep = int(rep_m.group(1)) if rep_m else None
    seed = int(seed_m.group(1)) if seed_m else None

    lines = text.splitlines()
    jobs: list[Job] = []
    in_jobs = False
    for line in lines:
        x = line.strip()
        if not x:
            continue
        if x.startswith("# Jobs"):
            in_jobs = True
            continue
        if in_jobs and x.startswith("#"):
            break
        if in_jobs:
            parts = x.split()
            if not parts[0].isdigit():
                continue
            if len(parts) == 3:
                vals = [parse_int(parts[0]), parse_int(parts[1]), parse_int(parts[2])]
            elif len(parts) >= 4:
                vals = [parse_int(parts[1]), parse_int(parts[2]), parse_int(parts[3])]
            else:
                continue
            if None in vals:
                continue
            p, d, w = vals
            jobs.append(Job(p=p, d=d, w=w))

    if not jobs:
        # Fallback to "Input format for C++ binaries" block: first find "n s", then n lines "p d w"
        nums = [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]
        for i in range(len(nums) - 1):
            head = nums[i].split()
            if len(head) == 2 and head[0].isdigit() and head[1].isdigit():
                nn = int(head[0])
                ss = int(head[1])
                if nn != n or ss != s:
                    continue
                cand: list[Job] = []
                for j in range(1, nn + 1):
                    if i + j >= len(nums):
                        break
                    row = nums[i + j].split()
                    if len(row) < 3:
                        break
                    if not (row[0].isdigit() and row[1].isdigit() and row[2].isdigit()):
                        break
                    cand.append(Job(p=int(row[0]), d=int(row[1]), w=int(row[2])))
                if len(cand) == nn:
                    jobs = cand
                    break

    if len(jobs) != n:
        return None

    return InstanceRecord(
        path=path,
        file_name=path.name,
        n=n,
        gamma=gamma,
        s=s,
        rep=rep,
        seed=seed,
        jobs=jobs,
    )


def format_obj(x: float) -> str:
    if x == float("inf"):
        return "inf"
    return f"{x:.6f}"


def update_txt_fields(path: Path, obj_value: float, status_value: str, time_value: float) -> None:
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    obj_line = f"obj_gurobi: {format_obj(obj_value)}"
    status_line = f"status_gurobi: {status_value}"
    time_line = f"time_gurobi: {time_value:.6f}"

    obj_idx = None
    status_idx = None
    time_idx = None
    for i, line in enumerate(lines):
        if line.startswith("obj_gurobi:"):
            obj_idx = i
        elif line.startswith("status_gurobi:"):
            status_idx = i
        elif line.startswith("time_gurobi:"):
            time_idx = i

    if obj_idx is not None:
        lines[obj_idx] = obj_line
    else:
        lines.append(obj_line)
    if status_idx is not None:
        lines[status_idx] = status_line
    else:
        lines.append(status_line)
    if time_idx is not None:
        lines[time_idx] = time_line
    else:
        lines.append(time_line)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def solve_one_instance(rec: InstanceRecord, effective_time_limit: int | None) -> tuple[float, str, float, int]:
    t0 = time.perf_counter()
    obj, status = solve_gurobi_generic(rec.n, rec.s, rec.jobs, time_limit=effective_time_limit)
    run_t = time.perf_counter() - t0

    if status in {"TIMEOUT", "TIME_LIMIT"}:
        status = "TIME_LIMIT"
        if effective_time_limit is not None:
            run_t = min(run_t, float(effective_time_limit))
        is_timeout = 1
    elif status == "OPTIMAL":
        is_timeout = 0
    else:
        is_timeout = 0
    return obj, status, run_t, is_timeout


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances-dir", type=str, default=str(ROOT / "results" / "instances_txt"))
    ap.add_argument("--glob", type=str, default="instance_*.txt", help="File glob under instances-dir.")
    ap.add_argument(
        "--time-limit",
        type=int,
        default=1800,
        help="Per-instance time limit in seconds. <=0 means no time limit.",
    )
    ap.add_argument("--raw-out", type=str, default=str(ROOT / "results" / "raw" / "gurobi_fill_detailed.csv"))
    ap.add_argument("--summary-out", type=str, default=str(ROOT / "results" / "summary" / "table_gurobi_only_table_ready.csv"))
    ap.add_argument("--backfill-txt", action="store_true", help="Write obj_gurobi/time_gurobi/status_gurobi back into instance txt files.")
    ap.add_argument("--workers", type=int, default=10, help="Number of parallel worker processes.")
    ap.add_argument("--quiet", action="store_true", help="Disable per-instance progress printing.")
    args = ap.parse_args()

    instances_dir = Path(args.instances_dir)
    raw_out = Path(args.raw_out)
    summary_out = Path(args.summary_out)
    raw_out.parent.mkdir(parents=True, exist_ok=True)
    summary_out.parent.mkdir(parents=True, exist_ok=True)

    records: list[InstanceRecord] = []
    bad_files = 0
    file_list = sorted(instances_dir.glob(args.glob))
    if not file_list and args.glob == "instance_*.txt":
        # Backward compatibility for legacy Class-I naming.
        file_list = sorted(instances_dir.glob("*.txt"))
    for fp in file_list:
        rec = parse_instance_txt(fp)
        if rec is None:
            bad_files += 1
            continue
        records.append(rec)

    raw_rows = []
    raw_header = [
        "instance_file", "n", "gamma", "s", "rep", "seed",
        "gurobi_obj", "gurobi_time", "gurobi_status",
        "is_timeout", "is_inferred", "reason"
    ]
    actual_calls = 0
    actual_timeouts = 0
    total_instances = len(records)
    effective_time_limit = args.time_limit if args.time_limit > 0 else None
    workers = max(1, int(args.workers))
    ordered_records = sorted(records, key=lambda r: r.file_name)

    def run_batch_with_executor(executor_cls) -> dict[int, dict]:
        nonlocal actual_calls, actual_timeouts
        done_count = 0
        pending_rows: dict[int, dict] = {}
        with executor_cls(max_workers=workers) as executor:
            future_to_meta: dict[concurrent.futures.Future, tuple[int, InstanceRecord]] = {}
            for idx, rec in enumerate(ordered_records):
                fut = executor.submit(solve_one_instance, rec, effective_time_limit)
                future_to_meta[fut] = (idx, rec)

            for fut in concurrent.futures.as_completed(future_to_meta):
                idx, rec = future_to_meta[fut]
                try:
                    obj, status, run_t, is_timeout = fut.result()
                except Exception as exc:
                    obj, status, run_t, is_timeout = float("inf"), f"ERROR_{type(exc).__name__}", 0.0, 0

                actual_calls += 1
                actual_timeouts += is_timeout
                done_count += 1

                if args.backfill_txt:
                    update_txt_fields(rec.path, obj, status, run_t)

                row = {
                    "instance_file": rec.file_name,
                    "n": rec.n,
                    "gamma": rec.gamma,
                    "s": rec.s,
                    "rep": rec.rep if rec.rep is not None else "",
                    "seed": rec.seed if rec.seed is not None else "",
                    "gurobi_obj": format_obj(obj),
                    "gurobi_time": f"{run_t:.6f}",
                    "gurobi_status": status,
                    "is_timeout": is_timeout,
                    "is_inferred": 0,
                    "reason": "",
                }
                pending_rows[idx] = row

                if not args.quiet:
                    print(
                        f"[{done_count}/{total_instances}] file={rec.file_name} "
                        f"(n={rec.n}, gamma={rec.gamma}, s={rec.s}, rep={rec.rep}) "
                        f"-> status={status}, obj={format_obj(obj)}, time={run_t:.3f}s",
                        flush=True,
                    )
        return pending_rows

    executor_mode = "process"
    try:
        pending_rows = run_batch_with_executor(concurrent.futures.ProcessPoolExecutor)
    except (PermissionError, OSError) as exc:
        executor_mode = "thread_fallback"
        if not args.quiet:
            print(f"[warn] ProcessPool unavailable ({type(exc).__name__}); fallback to ThreadPool.", flush=True)
        pending_rows = run_batch_with_executor(concurrent.futures.ThreadPoolExecutor)

    raw_rows = [pending_rows[i] for i in range(len(ordered_records))]
    with raw_out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=raw_header)
        w.writeheader()
        for row in raw_rows:
            w.writerow(row)

    # summary: rows (n,gamma), not split by s
    n_values = sorted({int(r["n"]) for r in raw_rows})
    g_values = sorted({float(r["gamma"]) for r in raw_rows})

    grouped: dict[tuple[int, float], list[dict]] = {}
    for r in raw_rows:
        key = (int(r["n"]), float(r["gamma"]))
        grouped.setdefault(key, []).append(r)

    summary_header = ["n", "gamma", "CPU_Grb", "TO_Grb", "Solved_Grb"]

    with summary_out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(summary_header)
        for n in n_values:
            for g in g_values:
                vals = grouped.get((n, g), [])
                if not vals:
                    row = [n, g, "--", "--", "--"]
                    w.writerow(row)
                    continue
                times = [float(v["gurobi_time"]) for v in vals]
                to_cnt = sum(1 for v in vals if v["gurobi_status"] in {"TIME_LIMIT", "TIMEOUT"})
                solved_cnt = sum(1 for v in vals if v["gurobi_status"] == "OPTIMAL")
                row = [n, g, f"{sum(times)/len(times):.4f}", str(to_cnt), str(solved_cnt)]
                w.writerow(row)

    print(f"parsed_instances={len(records)}")
    print(f"bad_files_skipped={bad_files}")
    print(f"actual_calls={actual_calls}")
    print(f"actual_timeouts={actual_timeouts}")
    print(f"time_limit={'NONE' if effective_time_limit is None else effective_time_limit}")
    print(f"workers={workers}")
    print(f"executor_mode={executor_mode}")
    print(f"backfill_txt={int(args.backfill_txt)}")
    print(f"raw_out={raw_out}")
    print(f"summary_out={summary_out}")


if __name__ == "__main__":
    main()
