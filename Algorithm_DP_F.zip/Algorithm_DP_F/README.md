# Algorithm_DP_F

Self-contained folder for DP-F experiments with three-way comparison:
- DP-F (baseline)
- DP-F-Speedup
- Gurobi

## Environment
```bash
source ../.venv_all_algorithms/bin/activate
python -c "import gurobipy as gp; print(gp.gurobi.version())"
```

## Build
```bash
bash scripts/build_cpp.sh
```
This builds:
- `bin/algorithm_dp_f`
- `bin/algorithm_dp_f_speedup`

## Generate Instances Only
```bash
python scripts/generate_classI_instances_random.py --clear-existing
```
This writes reproducible instances to `results/instances_txt` with `PENDING` placeholders.

## Solve Existing Instances (DP-F Baseline)
```bash
python scripts/DPF_solve_instances.py --backfill-txt
```
This reads `results/instances_txt/instance_*.txt` and writes:
- Raw detail: `results/raw/dp_f_fill_detailed.csv`
- Summary: `results/summary/table_dp_f_only_table_ready.csv`

Compatibility alias:
- `python scripts/DPF_base_solve_instances.py ...` (same behavior)

## Solve Existing Instances (DP-F Speedup)
```bash
python scripts/DPF_speedup_solve_instances.py --backfill-txt
```
This writes:
- Raw detail: `results/raw/dp_f_speedup_fill_detailed.csv`
- Summary: `results/summary/table_dp_f_speedup_only_table_ready.csv`

## Solve Existing Instances (Gurobi Only)
```bash
python scripts/Gurobi_solve_instances.py --backfill-txt
```
This writes:
- Raw detail: `results/raw/gurobi_fill_detailed.csv`
- Summary: `results/summary/table_gurobi_only_table_ready.csv`

## Time Limit Rule
- All solve scripts use `--time-limit` (default `1800` seconds).
- `TIME_LIMIT` and `TIMEOUT` are normalized as timeout events.
- DP scripts support `--max-unsolved-per-n-gamma` to skip remaining instances in a group after repeated unsolved outcomes.
