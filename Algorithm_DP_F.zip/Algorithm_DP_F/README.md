# Algorithm_DP_F

This folder contains Class-I benchmark experiments comparing `DP-F` (baseline), `DP-F Speedup`, and `Gurobi`.

## Directory Layout

- `scripts/`: instance generation, solve, and summary scripts
- `src/`: C++ / Python / Gurobi implementations
- `bin/`: compiled binaries
- `results/`: instance text files, detailed outputs, and summary tables

## Environment

Run in this directory:

```bash
source ../.venv_all_algorithms/bin/activate
python -c "import gurobipy as gp; print(gp.gurobi.version())"
```

The second command is only to verify that `gurobipy` is available. If you only run DP-F, you can skip it.

## Build (C++)

```bash
bash scripts/build_cpp.sh
```

Common outputs:

- `bin/algorithm_dp_f` (DP-F baseline)
- `bin/algorithm_dp_f_speedup_dpg_ub_pmtn_lb` (current speedup binary)

## Recommended Workflow (Step-by-Step)

### 1. Generate instances

```bash
python scripts/generate_classI_instances_random.py --clear-existing
```

Output directory: `results/instances_txt/` (instance text files with placeholder result fields).

### 2. Run DP-F (baseline)

```bash
python scripts/DPF_solve_instances.py --backfill-txt
```

Outputs:

- `results/raw/dp_f_fill_detailed.csv`
- `results/summary/table_dp_f_only_table_ready.csv`

### 3. Run DP-F Speedup

```bash
python scripts/DPF_speedup_solve_instances.py --backfill-txt
```

Outputs:

- `results/raw/dp_f_speedup_fill_detailed.csv`
- `results/summary/table_dp_f_speedup_only_table_ready.csv`

### 4. Run Gurobi

```bash
python scripts/Gurobi_solve_instances.py --backfill-txt
```

Outputs:

- `results/raw/gurobi_fill_detailed.csv`
- `results/summary/table_gurobi_only_table_ready.csv`

## Common Options

- `--time-limit 1800`: per-instance time limit in seconds (default: `1800`)
- `--time-limit <=0`: no time limit
- `--backfill-txt`: write solver results back into `results/instances_txt/*.txt`
- `--quiet`: disable per-instance progress output

Only available in `DPF_solve_instances.py` and `DPF_speedup_solve_instances.py`:

- `--max-unsolved-per-n-gamma 3`: skip the remaining instances in a `(n, gamma)` group after too many unsolved cases (`<0` disables this)


## Output Notes

- Solver scripts read `results/instances_txt/instance_*.txt`
- `raw/*.csv` stores per-instance detailed results
- `summary/*.csv` stores table-ready summaries
- Timeout statuses are normalized to `TIME_LIMIT` (covering both `TIMEOUT` and `TIME_LIMIT`)
