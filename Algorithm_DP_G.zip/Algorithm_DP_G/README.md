# Algorithm_DP_G

Self-contained folder for DP-G experiments (C++ DP + Gurobi comparison).

## Environment
```bash
source ../.venv_all_algorithms/bin/activate
python -c "import gurobipy as gp; print(gp.gurobi.version())"
```

## Build
```bash
bash scripts/build_cpp.sh
```
This builds:
- `bin/dp_g_solver`

## Run
```bash
python scripts/run_compare.py --repeats 10 --timeout 1800
```

## Solve Existing Instances (DP-G Only)
```bash
python scripts/DPG_solve_instances.py --backfill-txt
```
This reads `results/instances_txt/instance_*.txt`, runs `bin/dp_g_solver`, and writes:
- Raw detail: `results/raw/dp_g_fill_detailed.csv`
- Summary: `results/summary/table_dp_g_only_table_ready.csv`

Compatibility alias:
- `python scripts/DPG_base_solve_instances.py ...` (same behavior)

## Solve Existing Instances (Gurobi Only)
```bash
python scripts/Gurobi_solve_instances.py --backfill-txt
```
This reads `results/instances_txt/instance_*.txt`, runs `src/gurobi/gurobi_solver_dp_g.py`, and writes:
- Raw detail: `results/raw/gurobi_fill_detailed.csv`
- Summary: `results/summary/table_gurobi_only_table_ready.csv`

## Generate Instances Only
```bash
python scripts/generate_classIIB_instances_random.py --clear-existing
```
This writes reproducible instances to `results/instances_txt` with `PENDING` placeholders for:
- `obj_dp_g`
- `obj_gurobi`
- `time_dp_g`
- `time_gurobi`
- `dp_states_dp_g`
- `status_dp_g`
- `status_gurobi`

## Outputs
- Raw detail: `results/raw/detailed.csv`
- Table-ready summary: `results/summary/table_dp_g_table_ready.csv`

## 1800s termination rule (detailed)
- The run-level time limit is controlled by `--timeout` (default: `1800` seconds) and is applied to both DP-G and Gurobi in every repetition.
- DP-G timeout:
  - DP is executed via Python `subprocess.run(..., timeout=1800)`.
  - If timeout is hit, DP returns `dp_states = "TIME_LIMIT"` and is treated as non-optimal.
- Gurobi timeout:
  - Gurobi is configured with `TimeLimit = 1800`.
  - If the model is not proven optimal before the limit, status is recorded as `TIME_LIMIT` (or `TIMEOUT` if returned externally).
- `is_timeout = 1` for a repetition if any of the following is true:
  - `dp_states == "TIME_LIMIT"`;
  - `gurobi_status in {"TIME_LIMIT", "TIMEOUT"}`;
  - measured `dp_time >= 1800`;
  - measured `gurobi_time >= 1800`.
- Timeout handling is independent per solver.
- Monotone-n inferred-timeout rule (applied within each fixed `gamma`, with `n` increasing):
  - If DP times out in all repetitions at some `n`, then for larger `n` DP is not run and is marked `TIME_LIMIT_INFERRED`.
  - If Gurobi times out in all repetitions at some `n`, then for larger `n` Gurobi is not run and is marked `TIME_LIMIT_INFERRED`.
  - The two triggers are independent; one side may be inferred while the other still runs normally.
  - Even if both sides are inferred, instances are still generated and recorded for all larger `n`.
