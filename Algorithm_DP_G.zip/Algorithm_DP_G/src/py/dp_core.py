import subprocess
from pathlib import Path

class DPSolverG:
    def __init__(self, instance):
        self.instance = instance
        root = Path(__file__).resolve().parents[2]
        self.binary_path = root / "bin" / "dp_g_solver"
        if not self.binary_path.exists():
            raise FileNotFoundError(f"Binary not found at {self.binary_path}. Run scripts/build_cpp.sh first.")

    def solve(self, time_limit=None):
        input_str = f"{self.instance.n} {self.instance.s}\n"
        for job in self.instance.jobs:
            input_str += f"{job.p} {job.d} {job.w}\n"

        try:
            process = subprocess.run(
                [str(self.binary_path)],
                input=input_str,
                text=True,
                capture_output=True,
                check=True,
                timeout=time_limit,
            )
            line = process.stdout.strip().splitlines()[0] if process.stdout.strip() else ""
            if not line:
                return float("inf"), None
            parts = line.split()
            value = float(parts[0])
            states = int(parts[1]) if len(parts) > 1 else 0
            return value, states
        except subprocess.TimeoutExpired:
            return float("inf"), "TIME_LIMIT"
        except (subprocess.CalledProcessError, ValueError, IndexError):
            return float("inf"), None
