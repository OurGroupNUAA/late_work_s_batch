
import math
import random

class Job:
    def __init__(self, id, p, d, w):
        self.id = id
        self.p = p
        self.d = d
        self.w = w

    def __repr__(self):
        return f"J{self.id}(p={self.p}, d={self.d}, w={self.w})"

class Instance:
    def __init__(self, jobs, s):
        self.jobs = jobs  # List of Job objects
        self.s = s        # Setup time
        self.n = len(jobs)

class InstanceGenerator:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)

    def generate_agreeable_instance(self, n, s=1, p_range=(1, 10), d_range=(10, 50), w_range=(1, 10)):
        """
        To satisfy d_j1 <= d_j2 => p_j1 <= p_j2 AND w_j1 >= w_j2
        We generate n tuples, sort them, and combine to ensure the agreeable property.
        """
        ps = sorted([self.rng.randint(*p_range) for _ in range(n)])
        ds = sorted([self.rng.randint(*d_range) for _ in range(n)])
        ws = sorted([self.rng.randint(*w_range) for _ in range(n)], reverse=True)
        
        jobs = []
        for i in range(n):
            jobs.append(Job(i + 1, ps[i], ds[i], ws[i]))
            
        return Instance(jobs, s)


    def generate_class_II_B_instance(self, n, gamma=1.0):
        """
        Class II-B: Trunk-line Agreeable (Algorithm DP-G)
        - n: 100-500 (Practical), 1000-5000 (Stress)
        - s: U[300, 600]
        - p: U[5, 15]
        - w: U[1, 5]
        - Agreeable: p_1 <= ... <= p_n, d_1 <= ... <= d_n, w_1 >= ... >= w_n
        - Due dates: Discrete "delivery wave" model.
          Delta = 1800
          d_j in {Delta, 2*Delta, ..., ceil(gamma * sum(p) / Delta) * Delta}
        """
        s = self.rng.randint(300, 600)
        Delta = 1800

        # 1. Generate properties independently first
        p_raw = [self.rng.randint(5, 15) for _ in range(n)]
        w_raw = [self.rng.randint(1, 5) for _ in range(n)]
        
        sum_p = sum(p_raw)
        # Formula: ceil(gamma * sum_p / Delta)
        K = math.ceil((gamma * sum_p) / Delta)
        if K < 1: K = 1
        
        possible_dates = [k * Delta for k in range(1, K + 1)]
        d_raw = [self.rng.choice(possible_dates) for _ in range(n)]

        # 2. Sort to enforce agreeable condition
        # d_j ascending, p_j ascending, w_j descending
        # effectively j is the index in the sorted list
        ps = sorted(p_raw)
        ds = sorted(d_raw)
        ws = sorted(w_raw, reverse=True)

        jobs = []
        for i in range(n):
            jobs.append(Job(i + 1, ps[i], ds[i], ws[i]))
            
        return Instance(jobs, s)

# Legacy sample instance
jobs_sample = [
   Job(1, 3, 5, 8),
   Job(2, 5, 10, 8),
   Job(3, 5, 12, 2)
]
instance_agreeable_sample = Instance(jobs_sample, s=2)
