try:
    import gurobipy as gp
except ImportError:
    gp = None
import time

def solve_dp_g_gurobi(n, s, jobs, d_list=None, time_limit=1800):
    if gp is None:
        return float('inf'), 'GUROBI_NOT_INSTALLED'
    """
    Solves 1|s-batch, agreeable|Yw using Gurobi based on Lemma 4.
    ...
    """
    
    try:
        m = gp.Model("AgreeableBatch")
        m.setParam('TimeLimit', time_limit)
        m.setParam('OutputFlag', 0)
        m.setParam('Threads', 1)
        m.setParam('MIPGap', 0)
        m.setParam('IntegralityFocus', 1)
        
        # Upper bound on batches: no artificial cap.
        K = n
        
        batches = range(K)
        
        # Variables
        z = m.addVars(n, vtype=gp.GRB.BINARY, name="z") # 1 if late
        y = m.addVars(n, K, vtype=gp.GRB.BINARY, name="y") # 1 if job j in batch k
        u = m.addVars(K, vtype=gp.GRB.BINARY, name="u") # 1 if batch k used
        C = m.addVars(K, vtype=gp.GRB.CONTINUOUS, lb=0, name="C") # Completion time
        
        # Objective

        
        # Constraints
        
        # 1. Coverage
        for j in range(n):
            m.addConstr(sum(y[j,k] for k in batches) + z[j] == 1, name=f"Cover_{j}")
            
        # 2. Batch Usage
        for k in range(K):
            # If any job is in batch k, u[k] must be 1
            for j in range(n):
                m.addConstr(u[k] >= y[j,k], name=f"UseBatch_{k}_{j}")
                
        # 3. Batch Order (Fill 0..K)
        for k in range(K-1):
            m.addConstr(u[k] >= u[k+1], name=f"BatchSeq_{k}")
            
        # 4. Completion Times
        # Calculate Batch Processing Sum
        # C[0] = s*u[0] + sum(p*y[j,0])
        total_p = sum(job.p for job in jobs)
        BigM = total_p * 2 + n * s
        
        for k in range(K):
            p_sum = sum(jobs[j].p * y[j,k] for j in range(n))
            prev_C = C[k-1] if k > 0 else 0
            
            # C[k] >= prev_C + s + p_sum  (If u[k]=1)
            # C[k] >= 0 (If u[k]=0) -> Handled by lb
            # Logic: C[k] >= prev_C + s*u[k] + p_sum - M(1-u[k]) ? No.
            # If u[k]=0, C[k] should ideally be C[k-1] or 0.
            # But since we are minimizing late work (maximize early),
            # we want C[k] small to fit d.
            # Actually, standard formulation:
            m.addConstr(C[k] >= prev_C + s * u[k] + p_sum, name=f"Time_{k}")
            
        # 5. Partial Late Work (Straddling)
        # For jobs in batches, Late Work V[j] >= C[k] - d[j].
        # V[j] >= 0.
        # Cost += w[j] * V[j].
        # Note: If V[j] >= p[j], it's fully late. Optimal schedule would likely move it to z set, 
        # but model allows it here too (cost is linear increasing coeff w).
        # Actually min weighted late work. If V > p, we pay > wp?
        # Yes, technically Y_w = min(p, max(0, C-d)).
        # If we model V >= C - d, V can exceed p. 
        # But since we minimize sum(w * V), and fully late option z exists with cost w*p,
        # the solver naturally prefers z=1 if V > p.
        # So modelling V >= C - d is sufficient/exact under optimization.
        
        V = m.addVars(n, vtype=gp.GRB.CONTINUOUS, lb=0, name="V")
        
        for k in range(K):
            for j in range(n):
                # if y[j,k]=1 => V[j] >= C[k] - d[j]
                # V[j] >= C[k] - d[j] - BigM * (1 - y[j,k])
                m.addConstr(V[j] >= C[k] - d_list[j] - BigM * (1 - y[j,k]), name=f"LateVar_{j}_{k}")
                
        # Update Objective
        obj_expr = sum(jobs[j].w * jobs[j].p * z[j] for j in range(n)) + sum(jobs[j].w * V[j] for j in range(n))
        m.setObjective(obj_expr, gp.GRB.MINIMIZE)
                
        # 6. Order Preservation (Agreeable)
        # Use Auxiliary variables L[j] = Batch index of job j (if non-late) or L[j-1] (if late)
        # Enforce L[j] >= L[j-1].
        
        L = m.addVars(n, vtype=gp.GRB.CONTINUOUS, lb=0, ub=K, name="L")
        
        for j in range(n):
            batch_idx_j = sum(k * y[j,k] for k in batches)
            prev_L = L[j-1] if j > 0 else 0
            
            # Constraint 6a: Monotonicity
            m.addConstr(L[j] >= prev_L, name=f"L_Mono_{j}")
            
            # Constraint 6b: If non-late, L[j] must match batch_idx
            # L[j] >= batch_idx_j  (Always true if Late implies batch=0? No sum is 0. So L>=0 ok)
            # Actually we want L[j] to capture "Current Max Batch Index in non-late seq".
            
            # Constraints derived:
            # 1. L[j] >= prev_L
            # 2. L[j] >= batch_idx_j  (If Non-Late, L[j] >= k. Since L>=prev and k>=prev(implicitly), L=k or larger)
            # 3. If Late (z=1), L[j] <= prev_L  => L[j] = prev_L
            #    L[j] <= prev_L + K * (1 - z[j]) ? No. If z=1, K*(0)=0. L<=prev.
            #    Wait. (1-z[j]) is 0 if Late. So L<=prev.
            #    If Early (z=0), L<=prev + K. Loose.
            # 4. If Early (z=0), L[j] <= batch_idx_j
            #    L[j] <= batch_idx_j + K * z[j]
            
            m.addConstr(L[j] >= batch_idx_j, name=f"L_lb_{j}")
            m.addConstr(L[j] <= prev_L + K * (1 - z[j]), name=f"L_ub_late_{j}")
            m.addConstr(L[j] <= batch_idx_j + K * z[j], name=f"L_ub_early_{j}")
             
        # Optimize
        m.optimize()
        
        if m.SolCount > 0:
            return m.ObjVal, "OPTIMAL" if m.Status == gp.GRB.OPTIMAL else "TIME_LIMIT"
        else:
            return -1, "NO_SOLUTION" if m.Status == gp.GRB.TIME_LIMIT else f"STATUS_{m.Status}"
            
    except Exception as e:
        print(f"Gurobi Error: {e}")
        return 0, "ERROR"
