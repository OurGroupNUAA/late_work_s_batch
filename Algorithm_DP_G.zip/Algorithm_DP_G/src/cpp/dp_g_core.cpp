
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <atomic>
#include <cstdint>

#ifdef _OPENMP
#include <omp.h>
#endif

using namespace std;

// Memory-efficient type for costs
typedef int32_t CostType;
const CostType INF_VAL = 1000000000;
const int64_t INF = 1e18; // Logic level INF

struct Job {
    int id;
    int p;
    int d;
    int w;
};

// --- Storage Classes ---

class CompactDecisions {
    vector<uint64_t> data;
    size_t p_stride, t_stride;
    size_t start_j_offset;
public:
    CompactDecisions() : p_stride(0), t_stride(0), start_j_offset(0) {}
    
    void resize_with_strides(int n_rows, int P, int T, size_t offset = 0) {
        start_j_offset = offset;
        p_stride = P + 1;
        // Pad t_stride to be a multiple of 32 to ensure row alignment on uint64 boundaries.
        // This guarantees that different L values (handled by different threads) touch different uint64 words.
        t_stride = (T + 1 + 31) & ~31;
        size_t total = (size_t)n_rows * p_stride * t_stride;
        // Each item is 2 bits. 1 uint64 = 64 bits = 32 items.
        // Total uint64s needed = (total + 31) / 32.
        data.assign((total + 31) >> 5, 0xFFFFFFFFFFFFFFFFULL); 
    }

    inline void set_fast(int j, int L, int t, uint8_t val) {
        if (j < (int)start_j_offset) return;
        size_t idx = ((size_t)(j - start_j_offset) * p_stride + L) * t_stride + t;
        size_t block = idx >> 5;
        size_t shift = (idx & 31) << 1;
        
        // No atomic needed due to padding (unique block per L)
        uint64_t mask = ~(3ULL << shift);
        uint64_t insert = (uint64_t)(val & 3) << shift;
        data[block] = (data[block] & mask) | insert;
    }

    inline uint8_t get_fast(int j, int L, int t) const {
        if (j < (int)start_j_offset) return 3;
        size_t idx = ((size_t)(j - start_j_offset) * p_stride + L) * t_stride + t;
        size_t block = idx >> 5;
        size_t shift = (idx & 31) << 1;
        return (data[block] >> shift) & 3;
    }
};

class VectorLPrime {
    vector<uint32_t> data;
    size_t stride;
    size_t start_j_offset;
public:
    VectorLPrime() : stride(0), start_j_offset(0) {}
    void resize(size_t n_rows, size_t n_T, size_t start_offset = 0) {
        start_j_offset = start_offset;
        stride = n_T;
        data.assign(n_rows * stride, 0);
    }
    inline void set(int j_global, int t, uint32_t val) {
        if (j_global < (int)start_j_offset) return;
        size_t idx = (size_t)(j_global - start_j_offset) * stride + t;
        data[idx] = val;
    }
    inline uint32_t get(int j_global, int t) const {
        if (j_global < (int)start_j_offset) return 0;
        size_t idx = (size_t)(j_global - start_j_offset) * stride + t;
        return data[idx];
    }
};

class NullDecisions {
public:
    void resize_with_strides(int, int, int, size_t = 0) {}
    inline void set_fast(int, int, int, uint8_t) {}
};

class NullLPrime {
public:
    void resize(size_t, size_t, size_t = 0) {}
    inline void set(int, int, uint32_t) {}
};

// --- Solver ---

class DPSolverG {
public:
    int n, s;
    vector<int> p, d, w, id;
    vector<int> P_sum;
    vector<int> p_min;
    vector<CostType> reject_sum;
    int max_P, max_T;
    mutable atomic<long long> total_states{0};

    DPSolverG(int n_v, int s_v, const vector<Job>& jobs) : n(n_v), s(s_v) {
        p.assign(n + 2, 0); d.assign(n + 2, 0); w.assign(n + 2, 0); id.assign(n + 2, 0);
        for (int i = 0; i < n; ++i) {
            p[i+1]=jobs[i].p; d[i+1]=jobs[i].d; w[i+1]=jobs[i].w; id[i+1]=jobs[i].id;
        }
        P_sum.assign(n + 2, 0);
        for (int j = n; j >= 1; --j) P_sum[j] = p[j] + P_sum[j+1];
        p_min.assign(n+2, 1e9);
        for (int j = n; j >= 1; --j) p_min[j] = min(p[j], p_min[j+1]);
        
        max_P = P_sum[1];
        int full_T = (n + 1) * s + max_P + 10;
        int max_dom = 0;
        for (int j = 1; j <= n; ++j) {
            int v = d[j] + p[j] - 1;
            if (v > max_dom) max_dom = v;
        }
        if (max_dom < s) max_dom = s;
        max_T = min(full_T, max_dom);
        // max_T is capped by dominance: t >= d_j + p_j is never better than rejecting job j.

        reject_sum.assign(n + 2, 0);
        int64_t acc = 0;
        for (int j = n; j >= 1; --j) {
            acc += (int64_t)w[j] * (int64_t)p[j];
            if (acc > INF_VAL) acc = INF_VAL;
            reject_sum[j] = (CostType)acc;
        }
        reject_sum[n + 1] = 0;
    }

    pair<bool, int64_t> can_achieve_zero_late_work_fast() const {
        // Exact feasibility test for Y_w^*=0 under contiguous batches in current job order.
        // DP over number of batches k and first i jobs:
        // feasible[i][k] = whether first i jobs can be completed with zero late work in exactly k batches.
        int64_t checked_states = 0;
        vector<long long> pref(n + 1, 0LL);
        for (int i = 1; i <= n; ++i) pref[i] = pref[i - 1] + (long long)p[i];

        vector<uint8_t> prev(n + 1, 0), curr(n + 1, 0);
        prev[0] = 1; // 0 jobs with 0 batches.

        for (int k = 1; k <= n; ++k) {
            vector<int> pref_prev(n + 1, 0);
            pref_prev[0] = prev[0] ? 1 : 0;
            for (int t = 1; t <= n; ++t) pref_prev[t] = pref_prev[t - 1] + (prev[t] ? 1 : 0);

            fill(curr.begin(), curr.end(), 0);
            bool any_feasible = false;

            // For fixed k, C(i) = k*s + pref[i] is nondecreasing in i.
            // Since due dates are nondecreasing in agreeable instances, the first index
            // with d[idx] >= C(i) is also nondecreasing; advance with one pointer.
            int idx = 1;
            for (int i = k; i <= n; ++i) {
                checked_states++;
                long long C = (long long)k * (long long)s + pref[i];
                while (idx <= i && (long long)d[idx] < C) ++idx;
                if (idx > i) continue;

                int start_t = max(k - 1, idx - 1);
                int end_t = i - 1;
                if (start_t > end_t) continue;

                int cnt = pref_prev[end_t] - (start_t > 0 ? pref_prev[start_t - 1] : 0);
                if (cnt > 0) {
                    curr[i] = 1;
                    any_feasible = true;
                }
            }

            if (curr[n]) return {true, checked_states};
            if (!any_feasible) return {false, checked_states};
            prev.swap(curr);
        }
        return {false, checked_states};
    }

    template<typename DecStore, typename LStore>
    void compute_step(int j, const vector<CostType>& dp_next, vector<CostType>& dp_curr, 
                      DecStore& decisions, LStore& predictions) {
        
        int pj = p[j], dj = d[j], wj = w[j];
        // Dynamic t pruning: Non-late jobs cannot complete after this time.
        // H[t] (for unique non-late batch) and Join Batch also strictly respect this limit.
        int t_cutoff = min(max_T, dj + pj - 1);
        int loop_end_valid = t_cutoff;
        int t_start_min = 0;

        // 1. H[t] Optimized with Blocked Loop Interchange + Pruning
        // We only need H[t] for t <= t_cutoff because H[t] is used solely for the "Start Batch" non-late move.
        vector<CostType> H;
        vector<int> best_Lp;
        CostType reject_next = reject_sum[j + 1];
        
        const int T_BLOCK_SIZE = 512; 

        if (loop_end_valid >= t_start_min) {
            H.assign(loop_end_valid + 1, reject_next);
            best_Lp.assign(loop_end_valid + 1, 0);

            #pragma omp parallel
            {
                vector<CostType> local_H(loop_end_valid + 1, reject_next);
                vector<int> local_Lp(loop_end_valid + 1, 0);
                
                #pragma omp for schedule(dynamic)
                for (int t_start = 0; t_start <= loop_end_valid; t_start += T_BLOCK_SIZE) {
                    int t_end = min(loop_end_valid, t_start + T_BLOCK_SIZE - 1);
                    int limit_L_block = min((int)P_sum[j+1], max_T - s - t_start);
                    if (limit_L_block < 0) continue;

                    for (int Lp = 0; Lp <= limit_L_block; ++Lp) {
                        CostType* row_ptr = (CostType*)&dp_next[(size_t)Lp * (max_T+1)];
                        int t_limit_inner = min(t_end, max_T - s - Lp);
                        if (t_limit_inner < t_start) continue;
                        
                        for (int t = t_start; t <= t_limit_inner; ++t) {
                            CostType val = row_ptr[t + s + Lp];
                            // Branchless min for SIMD encouragement
                            if (val < local_H[t]) {
                                local_H[t] = val;
                                local_Lp[t] = Lp;
                            }
                        }
                    }
                }
                
                #pragma omp critical
                {
                    for (int t = 0; t <= loop_end_valid; ++t) 
                        if (local_H[t] < H[t]) { H[t] = local_H[t]; best_Lp[t] = local_Lp[t]; }
                }
            }
            
            #pragma omp parallel for
            for (int t = 0; t <= loop_end_valid; ++t) predictions.set(j, t, (uint32_t)best_Lp[t]);
        }

        vector<CostType> late_cost;
        if (loop_end_valid >= 0) {
            late_cost.resize(loop_end_valid + 1);
            for (int t = 0; t <= loop_end_valid; ++t) {
                late_cost[t] = (CostType)(wj * max(0, t - dj));
            }
        }

        // 2. Main DP
        int pm_next = (j < n) ? p_min[j+1] : 1e9;
        long long local_c = 0;

        #pragma omp parallel for schedule(dynamic) reduction(+:local_c)
        for (int L = 0; L <= P_sum[j]; ++L) {
            size_t row_idx = (size_t)L * (max_T + 1);
            int start_t = s + L;
            
            // L_forces_late: If L falls in "forbidden" gap, non-late is impossible REGARDLESS of t.
            bool L_forces_late = (p[j]>0 && (p_min[j] < L && L < pj)) || (pm_next < 1e9 && (pj < L && L < pj + pm_next));
            
            // PART A: Valid Zone (Possibility of Non-Late)
            // Range: [start_t, loop_end_valid]
            if (start_t <= loop_end_valid) {
                 for (int t = start_t; t <= loop_end_valid; ++t) {
                    local_c++;
                    CostType res = INF_VAL; uint8_t d_idx = 0;
                    
                    // Option 1: Late
                    if (L <= P_sum[j+1]) {
                        CostType v_late = dp_next[row_idx + t];
                        if (v_late < INF_VAL) res = v_late + (CostType)(wj * pj);
                    }
                    
                    // Option 2 & 3: Non-Late (Only if L allows)
                    if (!L_forces_late) {
                        CostType lw = late_cost[t];
                        
                        // Option 2: Join Batch
                        if (L >= pj + pm_next) {
                            int Lp = L - pj;
                            CostType v_join = dp_next[(size_t)Lp * (max_T + 1) + t];
                            if (v_join < INF_VAL) {
                                CostType cost = v_join + lw;
                                if (cost < res) { res = cost; d_idx = 1; }
                            }
                        }
                        // Option 3: Start Batch (Unique)
                        if (L == pj) {
                            CostType v_unique = H[t];
                            if (v_unique < INF_VAL) {
                                CostType cost = v_unique + lw;
                                if (cost < res) { res = cost; d_idx = 2; }
                            }
                        }
                    }
                    dp_curr[row_idx + t] = res;
                    if (res < INF_VAL) decisions.set_fast(j, L, t, d_idx);
                 }
            }

            // PART B: Late-Only Zone
            // Range: [max(start_t, loop_end_valid + 1), max_T]
            // In this range, t > t_cutoff, so non-late is impossible (dominated).
            // We only propagate "Late" option.
            int start_t_late = max(start_t, loop_end_valid + 1);
            if (start_t_late <= max_T) {
                 // Fast path: Just copy dp_next + cost if L is valid
                 if (L <= P_sum[j+1]) {
                     for (int t = start_t_late; t <= max_T; ++t) {
                         local_c++;
                         CostType v_late = dp_next[row_idx + t];
                         if (v_late < INF_VAL) {
                            dp_curr[row_idx + t] = v_late + (CostType)(wj * pj);
                             decisions.set_fast(j, L, t, 0); // 0 = Late
                         } else {
                             // dp_curr initialized to INF_VAL, so no op needed if v_late is INF
                         }
                     }
                 }
                 // If L > P_sum[j+1], Late is impossible too. Since dp_curr is init to INF, loop does nothing.
            }
        }
        total_states += local_c;
    }

    pair<int64_t, pair<vector<vector<int>>, int64_t>> solve() {
        CompactDecisions dec; VectorLPrime lp;
        dec.resize_with_strides(n + 1, max_P, max_T, 0); lp.resize(n + 1, max_T + 1, 0);
        vector<CostType> curr((size_t)(max_P + 1) * (max_T + 1), INF_VAL);
        vector<CostType> next((size_t)(max_P + 1) * (max_T + 1), INF_VAL);
        for (int t = s; t <= max_T; ++t) next[t] = 0; 
        for (int j = n; j >= 1; --j) {
            fill(curr.begin(), curr.end(), INF_VAL);
            compute_step(j, next, curr, dec, lp);
            curr.swap(next);
        }
        int64_t min_obj = INF; int best_L = -1;
        for (int L = 0; L <= max_P; ++L) {
            int t = s + L;
            if (t <= max_T && (int64_t)next[(size_t)L * (max_T + 1) + t] < min_obj) {
                min_obj = next[(size_t)L * (max_T + 1) + t]; best_L = L;
            }
        }
        return reconstruct_path(min_obj, best_L, dec, lp);
    }

    pair<int64_t, pair<vector<vector<int>>, int64_t>> solve_checkpoint(int K) {
        (void)K;
        vector<CostType> curr((size_t)(max_P + 1) * (max_T + 1), INF_VAL);
        vector<CostType> next((size_t)(max_P + 1) * (max_T + 1), INF_VAL);
        for (int t = s; t <= max_T; ++t) next[t] = 0;
        NullDecisions nd; NullLPrime nl;
        for (int j = n; j >= 1; --j) {
            fill(curr.begin(), curr.end(), INF_VAL);
            compute_step(j, next, curr, nd, nl);
            curr.swap(next);
        }
        int64_t min_obj = INF; int best_L = -1;
        for (int L = 0; L <= max_P; ++L) {
            int t = s + L;
            if (t <= max_T && (int64_t)next[(size_t)L * (max_T + 1) + t] < min_obj) {
                min_obj = next[(size_t)L * (max_T + 1) + t]; best_L = L;
            }
        }
        if (best_L == -1) return { INF, {{}, 0} };

        // Dummy reconstruction for paper results (only need obj and states)
        return {min_obj, {{}, 0}};
    }

    pair<int64_t, pair<vector<vector<int>>, int64_t>> reconstruct_path(int64_t mo, int bL, const CompactDecisions& dec, const VectorLPrime& lp) {
        vector<vector<int>> batches; vector<int> late;
        int cj = 1, cL = bL, ct = s + bL;
        while (cj <= n) {
            uint8_t di = dec.get_fast(cj, cL, ct);
            if (di == 0) { late.push_back(id[cj]); cj++; }
            else if (di == 1) { batches.push_back({id[cj]}); cL -= p[cj]; cj++; }
            else if (di == 2) { batches.push_back({id[cj]}); int nL = (int)lp.get(cj, ct); ct = ct + s + nL; cL = nL; cj++; }
            else break;
        }
        return {mo, {batches, 0}};
    }
};

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    int n, s; if (!(cin >> n >> s)) return 0;
    vector<Job> jobs(n);
    for (int i = 0; i < n; ++i) { jobs[i].id = i + 1; cin >> jobs[i].p >> jobs[i].d >> jobs[i].w; }
    DPSolverG solver(n, s, jobs);

    pair<int64_t, pair<vector<vector<int>>, int64_t>> res;
    if (n >= 500) res = solver.solve_checkpoint(10000);
    else res = solver.solve();
    cout << fixed << setprecision(2) << (double)res.first << " " << (long long)solver.total_states.load() << endl;
    return 0;
}
