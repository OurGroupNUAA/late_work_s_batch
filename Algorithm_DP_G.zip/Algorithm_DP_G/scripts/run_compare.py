#!/usr/bin/env python3
import argparse
import csv
import time
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src" / "py"))
sys.path.insert(0, str(ROOT / "src" / "gurobi"))

from instances import InstanceGenerator
from dp_core import DPSolverG
from gurobi_solver_dp_g import solve_dp_g_gurobi


def parse_int_list(raw):
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


def parse_float_list(raw):
    return [float(x.strip()) for x in raw.split(",") if x.strip()]

def gamma_tag(g):
    return f"g{g:g}"


def fmt_obj(x):
    if x is None:
        return "PENDING"
    try:
        xf = float(x)
        if xf == float("inf"):
            return "inf"
        return f"{xf:.6f}"
    except Exception:
        return str(x)


def fmt_time(x):
    if x is None:
        return "PENDING"
    try:
        return f"{float(x):.6f}"
    except Exception:
        return str(x)


def write_instance_txt(
    path, instance_id, n, gamma, rep, seed, inst,
    dp_obj, grb_obj, dp_states, dp_status, grb_status,
    dp_time, grb_time, dp_reason, grb_reason
):
    with path.open("w", encoding="utf-8") as f:
        f.write("# Reproducible instance for Algorithm_DP_G\n")
        f.write(f"instance_id: {instance_id}\n")
        f.write(f"n: {n}\n")
        f.write(f"gamma: {gamma}\n")
        f.write(f"s: {inst.s}\n")
        f.write(f"rep: {rep}\n")
        f.write(f"seed: {seed}\n")
        f.write("\n")
        f.write("# Jobs (id p d w)\n")
        for j in inst.jobs:
            f.write(f"{j.id} {j.p} {j.d} {j.w}\n")
        f.write("\n")
        f.write("# Optimal objective values / solver status\n")
        f.write(f"obj_dp_g: {fmt_obj(dp_obj)}\n")
        f.write(f"obj_gurobi: {fmt_obj(grb_obj)}\n")
        f.write(f"time_dp_g: {fmt_time(dp_time)}\n")
        f.write(f"time_gurobi: {fmt_time(grb_time)}\n")
        f.write(f"dp_states_dp_g: {dp_states if dp_states is not None else 'PENDING'}\n")
        f.write(f"status_dp_g: {dp_status if dp_status is not None else 'PENDING'}\n")
        f.write(f"status_gurobi: {grb_status if grb_status is not None else 'PENDING'}\n")
        if dp_reason:
            f.write(f"reason_dp_g: {dp_reason}\n")
        if grb_reason:
            f.write(f"reason_gurobi: {grb_reason}\n")
        if dp_status == "TIME_LIMIT_INFERRED" or grb_status == "TIME_LIMIT_INFERRED":
            f.write("\n")
            f.write("# Notes\n")
            f.write("# TIME_LIMIT_INFERRED: timeout inferred by monotone-n rule within same gamma.\n")
            f.write("# Trigger: solver timed out for all repeats at a smaller n; this instance has larger n.\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repeats", type=int, default=10)
    ap.add_argument("--timeout", type=int, default=1800)
    ap.add_argument("--seed-start", type=int, default=20260209)
    ap.add_argument("--n-list", type=str, default="100,200,300,400,500,1000,2000,3000,4000,5000")
    ap.add_argument("--gamma-list", type=str, default="0.5,0.7,0.9")
    ap.add_argument("--generate-only", action="store_true",
                    help="Only generate instance txt files with PENDING result fields.")
    args = ap.parse_args()

    n_list = parse_int_list(args.n_list)
    g_list = parse_float_list(args.gamma_list)

    inst_dir = ROOT / "results" / "instances_txt"
    inst_dir.mkdir(parents=True, exist_ok=True)

    if args.generate_only:
        instance_id = 0
        for n in n_list:
            for gamma in g_list:
                for rep in range(1, args.repeats + 1):
                    seed = args.seed_start + rep - 1
                    gen = InstanceGenerator(seed=seed)
                    inst = gen.generate_class_II_B_instance(n, gamma=gamma)
                    instance_id += 1
                    inst_txt_path = inst_dir / f"instance_{instance_id:04d}_n{n}_g{gamma}_rep{rep}.txt"
                    write_instance_txt(
                        inst_txt_path, instance_id, n, gamma, rep, seed, inst,
                        None, None, None, None, None, None, None, "", ""
                    )
                    print(
                        f"Generated instance {instance_id} "
                        f"(n={n}, gamma={gamma}, rep={rep}, seed={seed}) -> txt={inst_txt_path}"
                    )
        print(f"Wrote {instance_id} instances to: {inst_dir}")
        return

    raw_dir = ROOT / "results" / "raw"
    sum_dir = ROOT / "results" / "summary"
    raw_dir.mkdir(parents=True, exist_ok=True)
    sum_dir.mkdir(parents=True, exist_ok=True)
    detailed_path = raw_dir / "detailed.csv"
    summary_path = sum_dir / "table_dp_g_table_ready.csv"

    with detailed_path.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "instance_id","n","gamma","rep","seed",
            "dp_obj","gurobi_obj","dp_time","gurobi_time","dp_states",
            "dp_status","gurobi_status","dp_reason","gurobi_reason","match","is_timeout"
        ])

    grouped = {}
    instance_id = 0

    dp_forced_timeout = {gamma: False for gamma in g_list}
    grb_forced_timeout = {gamma: False for gamma in g_list}

    for n in n_list:
        for gamma in g_list:
            key = (n, gamma)
            grb_t, dp_t, st = [], [], []
            dp_timeout_count, grb_timeout_count = 0, 0
            dp_stop_in_group = False
            grb_stop_in_group = False
            for rep in range(1, args.repeats + 1):
                seed = args.seed_start + rep - 1
                gen = InstanceGenerator(seed=seed)
                inst = gen.generate_class_II_B_instance(n, gamma=gamma)
                d_list = [j.d for j in inst.jobs]
                instance_id += 1

                dp_reason = ""
                grb_reason = ""
                dp_is_timeout_actual = False
                grb_is_timeout_actual = False
                if dp_forced_timeout[gamma]:
                    dp_obj = float("inf")
                    dp_states = "TIME_LIMIT_INFERRED"
                    dp_status = "TIME_LIMIT_INFERRED"
                    dp_time = float(args.timeout)
                    dp_reason = "INFERRED_BY_MONO_N"
                elif dp_stop_in_group:
                    dp_obj = float("inf")
                    dp_states = "TIME_LIMIT_INFERRED"
                    dp_status = "TIME_LIMIT_INFERRED"
                    dp_time = float(args.timeout)
                    dp_reason = "INFERRED_BY_SAME_NG_TIMEOUT"
                else:
                    t0 = time.perf_counter()
                    dp_obj, dp_states = DPSolverG(inst).solve(time_limit=args.timeout)
                    dp_time = time.perf_counter() - t0
                    dp_status = "OPTIMAL" if dp_obj != float("inf") and dp_states not in (None, "TIME_LIMIT") else str(dp_states or "ERROR")
                    dp_is_timeout_actual = (dp_status in {"TIMEOUT", "TIME_LIMIT"}) or (dp_time >= args.timeout)
                    if dp_is_timeout_actual:
                        dp_stop_in_group = True

                if grb_forced_timeout[gamma]:
                    grb_obj = float("inf")
                    grb_status = "TIME_LIMIT_INFERRED"
                    grb_time = float(args.timeout)
                    grb_reason = "INFERRED_BY_MONO_N"
                elif grb_stop_in_group:
                    grb_obj = float("inf")
                    grb_status = "TIME_LIMIT_INFERRED"
                    grb_time = float(args.timeout)
                    grb_reason = "INFERRED_BY_SAME_NG_TIMEOUT"
                else:
                    t1 = time.perf_counter()
                    grb_obj, grb_status = solve_dp_g_gurobi(n, inst.s, inst.jobs, d_list=d_list, time_limit=args.timeout)
                    grb_time = time.perf_counter() - t1
                    grb_is_timeout_actual = (grb_status in {"TIMEOUT", "TIME_LIMIT"}) or (grb_time >= args.timeout)
                    if grb_is_timeout_actual:
                        grb_stop_in_group = True

                dp_is_timeout = (dp_status in {"TIMEOUT", "TIME_LIMIT", "TIME_LIMIT_INFERRED"}) or (dp_time >= args.timeout)
                grb_is_timeout = (grb_status in {"TIMEOUT", "TIME_LIMIT", "TIME_LIMIT_INFERRED"}) or (grb_time >= args.timeout)
                match = dp_status == "OPTIMAL" and grb_status == "OPTIMAL" and abs(dp_obj - grb_obj) <= 1e-6
                is_timeout = dp_is_timeout or grb_is_timeout

                if dp_is_timeout:
                    dp_timeout_count += 1
                if grb_is_timeout:
                    grb_timeout_count += 1

                with detailed_path.open("a", newline="") as f:
                    w = csv.writer(f)
                    w.writerow([
                        instance_id, n, gamma, rep, seed,
                        dp_obj, grb_obj, f"{dp_time:.6f}", f"{grb_time:.6f}", dp_states,
                        dp_status, grb_status, dp_reason, grb_reason, int(match), int(is_timeout)
                    ])

                inst_txt_path = inst_dir / f"instance_{instance_id:04d}_n{n}_g{gamma}_rep{rep}.txt"
                write_instance_txt(
                    inst_txt_path, instance_id, n, gamma, rep, seed, inst,
                    dp_obj, grb_obj, dp_states, dp_status, grb_status,
                    dp_time, grb_time, dp_reason, grb_reason
                )
                print(
                    f"Instance {instance_id} (n={n}, gamma={gamma}, rep={rep}, seed={seed}) "
                    f"-> obj: DP-G={fmt_obj(dp_obj)}, Gurobi={fmt_obj(grb_obj)} "
                    f"| status: DP-G={dp_status}, Gurobi={grb_status} | txt={inst_txt_path}"
                )

                grb_t.append(grb_time)
                dp_t.append(dp_time)
                if isinstance(dp_states, int):
                    st.append(dp_states)

            if (not dp_forced_timeout[gamma]) and dp_timeout_count == args.repeats:
                dp_forced_timeout[gamma] = True
                print(f"[INFERRED] DP-G inferred-timeout activated at gamma={gamma}, n={n}; larger n will be marked TIME_LIMIT_INFERRED.")
            if (not grb_forced_timeout[gamma]) and grb_timeout_count == args.repeats:
                grb_forced_timeout[gamma] = True
                print(f"[INFERRED] Gurobi inferred-timeout activated at gamma={gamma}, n={n}; larger n will be marked TIME_LIMIT_INFERRED.")

            grouped[key] = (
                sum(grb_t) / len(grb_t) if grb_t else float("nan"),
                sum(dp_t) / len(dp_t) if dp_t else float("nan"),
                (sum(st) / len(st)) if st else None,
                dp_timeout_count,
                grb_timeout_count,
            )

    with summary_path.open("w", newline="") as f:
        w = csv.writer(f)
        header = ["n"]
        for g in g_list:
            tag = gamma_tag(g)
            header.extend([
                f"CPU_Grb_{tag}", f"CPU_DP-G_{tag}", f"States_DP-G_{tag}",
                f"TO_DP-G_{tag}", f"TO_Grb_{tag}"
            ])
        w.writerow(header)
        for n in n_list:
            row = [n]
            for g in g_list:
                val = grouped.get((n, g))
                if val is None:
                    row.extend(["--", "--", "--", "--", "--"])
                else:
                    states_val = "--" if val[2] is None else f"{val[2]:.1f}"
                    row.extend([f"{val[0]:.4f}", f"{val[1]:.4f}", states_val, str(val[3]), str(val[4])])
            w.writerow(row)

    print(f"Wrote: {detailed_path}")
    print(f"Wrote: {summary_path}")


if __name__ == "__main__":
    main()
